# Copyright (c) 2014 Red Hat Inc.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from oslo_config import cfg
from oslo_log import log as logging

from cisco_controller.common import constants as cc_const

from keystoneauth1.exceptions import discovery
from keystoneauth1.identity import generic
from keystoneauth1 import session
from keystoneclient import client as keyclient
from keystoneclient import exceptions as keystone_exceptions
from neutronclient.neutron import client as neutronclient
from novaclient import client as novaclient

from neutron_lib import constants as n_consts

from neutron.db import api as db_api
from neutron.db.models import securitygroup
from neutron.db import models_v2
from neutron.db import provisioning_blocks
from neutron import manager
from neutron_lib.callbacks import resources
from neutron_lib import context as neutron_context


class NoTenantName(Exception):
    pass


LOG = logging.getLogger(__name__)
NEUTRON_CLIENT_API_VERSION = 2
VTC_PROVISIONING_ENTITY = 'VTC'
MAX_TENANT_NAME_LEN = 15


def try_del(d, keys):
    """Ignore key errors when deleting from a dictionary."""
    for key in keys:
        try:
            del d[key]
        except KeyError:
            pass


def get_portipaddress_from_portid(port_id, subnet_id):
    try:
        context = neutron_context.get_admin_context()
        plugin = manager.NeutronManager.get_plugin()
        port = plugin.get_port(context, port_id)
        if 'fixed_ips' in port:
            for fixed_ip in port['fixed_ips']:
                if fixed_ip['subnet_id'] == subnet_id:
                    return fixed_ip['ip_address']
        LOG.error("No IP address found for port id: %(port_id)s "
                  "subnet_id: %(subnet_id)s",
                  {'port_id': port_id,
                   'subnet_id': subnet_id})
    except Exception as e:
        LOG.error("Error getting port ip address for port id: %(port_id)s "
                  "subnet_id: %(subnet_id)s error: %(error)s",
                  {'port_id': port_id,
                   'subnet_id': subnet_id,
                   'error': e.message})
    return None


def _get_nova_client():
    keystone_conf = cfg.CONF.keystone_authtoken

    client = novaclient.Client(cc_const.NOVA_API_VERSION,
                               keystone_conf.admin_user,
                               keystone_conf.admin_password,
                               keystone_conf.admin_tenant_name,
                               keystone_conf.auth_url.rstrip('/') + '/v3/')

    return client


def _get_instance_state(instance_id):
    client = _get_nova_client()
    instance = client.servers.find(id=instance_id)
    return instance.status


def _get_neutron_plugin():
    return manager.NeutronManager.get_plugin()


def delete_port_for_failed_instance(row):
    if not cfg.CONF.ml2_cc.delete_failed_instance_port:
        return
    state = _get_instance_state(row.data['device_id'])
    if state.upper() != 'ERROR':
        return

    # Call the neutron API to delete this port
    LOG.error("Instance attached to port %s is in "
              "ERROR state, deleting port" % row.object_uuid)
    try:
        context = neutron_context.get_admin_context()
        plugin = _get_neutron_plugin()
        plugin.delete_port(context, row.object_uuid)
    except Exception as e:
        LOG.error("Error deleting port %(port)s, "
                  "error: %(error)s",
                  {'port': row.object_uuid, 'error': e.message})


def _set_port_status(port_id, status):
    session = db_api.get_writer_session()
    try:
        port = session.query(models_v2.Port).filter_by(id=port_id).one()
        port['status'] = status
        session.flush()
    except Exception:
        LOG.warning("ERROR setting port %(id)s to %(status)s",
                    {'id': port_id, 'status': status})


def set_port_status_active(row):
    LOG.info("Setting port status for router %(id)s interface "
             "%(subnet)s to ACTIVE",
             {'id': row.data['id'], 'subnet': row.data['subnet_id']})
    _set_port_status(row.data['port_id'], n_consts.PORT_STATUS_ACTIVE)


def provision_complete(row):
    if not row.provision:
        return
    try:
        resource = OBJECT_TYPE_TO_RESOURCE_MAP[row.object_type]
    except KeyError:
        return
    context = neutron_context.get_admin_context()
    provisioning_blocks.provisioning_complete(
        context, row.data['id'], resource,
        VTC_PROVISIONING_ENTITY)


def post_row_operation_methods(row):
    ob = POST_ROW_OPERATION_METHOD_MAP.get(row.object_type, {})
    for method in ob.get(row.operation, []):
        method(row)

    provision_complete(row)


# Post operation map, To be run after a successful sync operation
# Format: {object_type : { operation: [<list of methods to run>]}}
POST_ROW_OPERATION_METHOD_MAP = {
    cc_const.CC_PORT: {
        cc_const.CC_UPDATE: [delete_port_for_failed_instance]
    },
    cc_const.CC_ROUTER_INTF: {
        cc_const.CC_ADD: [set_port_status_active]
    }
}


OBJECT_TYPE_TO_RESOURCE_MAP = {
    cc_const.CC_PORT: resources.PORT
}


def _get_session():
    conf = cfg.CONF.keystone_authtoken
    nova_conf = cfg.CONF.nova

    def get_param(configOpts, firstOption, secondOption=None,
                  secondConfigOpts=None, acceptNone=False, value=None):
        try:
            v = configOpts.get(firstOption)
            if v is not None:
                return v
            elif acceptNone:
                return v
            return value
        except cfg.NoSuchOptError:
            if secondOption is None:
                return value
            if secondConfigOpts is None:
                return configOpts.get(secondOption)
            return secondConfigOpts.get(secondOption)

    params = dict(auth_url=get_param(conf, 'auth_url', 'identity_uri'),
                  username=get_param(conf, 'username', 'admin_user'),
                  password=get_param(conf, 'password', 'admin_password'),
                  tenant_name=get_param(nova_conf, 'project_name',
                                        'admin_tenant_name', conf),
                  project_domain_name=get_param(conf, 'project_domain_name',
                                                value='Default'),
                  user_domain_name=get_param(conf, 'user_domain_name',
                                             value='Default'))
    LOG.debug("Session Password params: %s" % params)

    auth = generic.Password(**params)
    return session.Session(auth=auth)


_cached_session = None


def _get_cached_session():
    global _cached_session
    if _cached_session is None:
        _cached_session = _get_session()
    return _cached_session


def _get_tenant_name(tenant_id):
    try:
        session = _get_cached_session()
        client = keyclient.Client(session=session)
    except discovery.DiscoveryFailure as de:
        LOG.error('Error with keystone discovery: %s', de.message)
        return None
    try:
        tenant = client.projects.get(tenant_id)
        return tenant.name
    except keystone_exceptions.NotFound:
        LOG.error('Cannot find project/tenant: %s', tenant_id)
        return None


def get_neutron_client():
    return neutronclient.Client(NEUTRON_CLIENT_API_VERSION,
                                session=_get_cached_session())


_cached_tenants = dict()


def _get_cached_tenant_name(tenant_id):
    global _cached_tenants
    try:
        return _cached_tenants[tenant_id]
    except KeyError:
        name = _get_tenant_name(tenant_id)
        if not name:
            return None
        _cached_tenants[tenant_id] = name
        return name


def update_tenant_info(data):
    if not isinstance(data, dict):
        return
    if 'tenant_id' not in data:
        if 'current_trunk' not in data and 'original_trunk' not in data:
            LOG.warning("No trunk data in %s", data['id'])
            return
        trunk = data['current_trunk'] or data['original_trunk']
        if not trunk:
            LOG.warning("trunk data is empty in %s", data['id'])
            return
        tenant_id = trunk['tenant_id']
    else:
        tenant_id = data['tenant_id']

    tenant_name = _get_cached_tenant_name(tenant_id)
    if not tenant_name:
        raise NoTenantName
    if len(tenant_name) > MAX_TENANT_NAME_LEN:
        short_tenant_name = tenant_name[-MAX_TENANT_NAME_LEN:]
        LOG.warning("Tenant name: '%(tenant_name)s' for id: %(tenant_id)s "
                    "is longer than the maximum: %(max_len)d, taking the "
                    "last chars: '%(short_tenant_name)s'",
                    {'tenant_name': tenant_name,
                     'short_tenant_name': short_tenant_name,
                     'tenant_id': tenant_id,
                     'max_len': MAX_TENANT_NAME_LEN})
        tenant_name = short_tenant_name
    data['tenant_name'] = tenant_name


def _get_default_security_group_tenant(session, tenant_id,
                                       security_group_name='default'):
    default_sg = session.query(securitygroup.SecurityGroup).\
        filter_by(project_id=tenant_id).\
        filter_by(name=security_group_name).first()
    return default_sg


def _get_default_security_group_rules(session, default_security_group):
    default_security_group_rules = \
        session.query(securitygroup.SecurityGroupRule).\
        filter_by(security_group_id=default_security_group['id']).all()
    return default_security_group_rules
