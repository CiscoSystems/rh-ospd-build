# Copyright 2017 cisco Systems inc
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

import base64
import hashlib
import sys

from Crypto.Cipher import AES

NCS_PASSWORD_SALT = u"ncsPassword123456789"
if (sys.version_info > (3, 0)):
    PADDING = b'\f'
else:
    PADDING = '\f'


class PasswordIsNotEncrypted(Exception):
    pass


def _encrypt_with_secret(secret, password):
    block_size = 16
    pad = lambda s: s + ((block_size - len(s) % block_size) *
                         PADDING.decode('utf-8'))
    encode = lambda c, s: base64.b64encode(c.encrypt(pad(s)))
    cipher = AES.new(secret)
    return encode(cipher, password)


def _decrypt_with_secret(secret, encrypted_password):
    decode = lambda c, e: c.decrypt(base64.b64decode(e)).rstrip(PADDING)
    cipher = AES.new(secret)
    try:
        return decode(cipher, encrypted_password)
    except (TypeError, ValueError):
        raise PasswordIsNotEncrypted


def _create_secret(salt):
    sha = hashlib.sha256()
    sha.update(salt.encode('utf-8'))
    return sha.digest()


def _decode_bytes(b):
    if sys.version_info > (3, 0):
        return b.decode('utf-8')
    return b


def encrypt(password):
    """Encrypt a password

    Provide a password to be encrypted, returns the encrypted string.
    :param password: Password to encrypt
    :return: Encrypted password
    """
    secret = _create_secret(NCS_PASSWORD_SALT)
    encrypted_pass = _encrypt_with_secret(secret, password)
    return _decode_bytes(encrypted_pass)


def decrypt(encrypted_password):
    """Decrypt an encrypted password

    Decrypt an already encrypted password, returns the decrypted text.
    :param encrypted_password: Encrypted password
    :return: Password after decryption

    >>> decrypt(encrypt('password'))
    'password'
    """
    secret = _create_secret(NCS_PASSWORD_SALT)
    decrypted_pass = _decrypt_with_secret(secret, encrypted_password)
    return _decode_bytes(decrypted_pass)
