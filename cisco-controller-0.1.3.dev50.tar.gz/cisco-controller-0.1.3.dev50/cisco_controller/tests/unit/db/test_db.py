# Copyright (c) 2015 OpenStack Foundation
#
#  Licensed under the Apache License, Version 2.0 (the "License"); you may
#  not use this file except in compliance with the License. You may obtain
#  a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#  WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#  License for the specific language governing permissions and limitations
#  under the License.
#

import mock
from unittest2.case import TestCase

from cisco_controller.common import constants as cc_const
from cisco_controller.common import utils
from cisco_controller.db import db
from cisco_controller.db import models

from neutron.db import api as neutron_db_api
from neutron.tests.unit.testlib_api import SqlTestCaseLight


TEST_TENANT_NAME = 'tenant_name'


class DbTestCase(SqlTestCaseLight, TestCase):

    UPDATE_ROW = [cc_const.CC_NETWORK, 'id', cc_const.CC_UPDATE,
                  {'test': 'data', 'tenant-id': 'test-tenant'},
                  {'test': 'data', 'tenant_id': 'test-tenant'}, {}]

    def setUp(self):
        super(DbTestCase, self).setUp()
        self.db_session = neutron_db_api.get_writer_session()
        self.db_engine = \
            neutron_db_api.context_manager.get_legacy_facade().get_engine()
        mock.patch.object(utils,
                          '_get_tenant_name',
                          return_value=TEST_TENANT_NAME).start()

    def _test_retry_count(self, retry_num, expected_retry_count):
        # add new pending row
        db.create_row(self.db_session, *self.UPDATE_ROW)

        # update the row with the requested retry_num
        row = db.get_all_db_rows(self.db_session)[0]
        row.retry_count = retry_num - 1
        db.inc_db_row_retry(self.db_session, row)

        # validate the state and the retry_count of the row
        row = db.get_all_db_rows(self.db_session)[0]
        self.assertEqual(expected_retry_count, row.retry_count)

    def test_get_oldest_pending_row_none_when_no_rows(self):
        rows = db.get_ordered_rows(self.db_session)
        self.assertEqual(0, rows.count())

    def test_get_oldest_pending_row(self):
        db.create_row(self.db_session, *self.UPDATE_ROW)
        rows = db.get_ordered_rows(self.db_session)
        self.assertNotEqual(0, rows.count())

    def test_validate_w_no_change(self):
        validation_result = db._validate_schema(self.db_engine,
                                                models.JournalTable)
        self.assertIsNone(validation_result)

    def test_validate_w_different_schema(self):
        con = self.db_session.connection()
        con.execute('DROP TABLE {tablename}'
                    ''.format(tablename=models.JournalTable.__tablename__))
        con.execute('CREATE TABLE {tablename} (id integer primary key, '
                    'data varchar(10))'
                    ''.format(tablename=models.JournalTable.__tablename__))
        validation_result = db._validate_schema(self.db_engine,
                                                models.JournalTable)
        self.assertNotEqual(validation_result, None)
        db.init_db(self.db_engine, models.JournalTable)

    def test_reset_id(self):
        db.create_row(self.db_session, *self.UPDATE_ROW)
        rows = db.get_ordered_rows(self.db_session)
        self.assertNotEqual(0, rows.count())
        db.create_row(self.db_session, *self.UPDATE_ROW)
        rows = db.get_ordered_rows(self.db_session)
        self.assertEqual(2, rows.count())
        for row in rows:
            db.delete_row(self.db_session, exact_id=row.id)
        db.reset_autoinc(self.db_session)
        db.create_row(self.db_session, *self.UPDATE_ROW)
        rows = db.get_ordered_rows(self.db_session)
        self.assertEqual(1, rows.count())
        [row] = rows
        self.assertEqual(1, row.id)

    def test_retry_count(self):
        self._test_retry_count(1, 1)

    def _test_maintenance_lock_unlock(self, is_lock, existing_state,
                                      expected_state, expected_result):
        row = models.MaintenanceTable(id='test',
                                      state=existing_state)
        self.db_session.add(row)
        self.db_session.flush()

        if is_lock:
            func_result = db.lock_maintenance(self.db_session, 'node')
        else:
            func_result = db.unlock_maintenance(self.db_session)
        self.assertEqual(expected_result, func_result)
        row = self.db_session.query(models.MaintenanceTable).one()
        self.assertEqual(expected_state, row['state'])

    def test_lock_maintenance(self):
        self._test_maintenance_lock_unlock(True,
                                           cc_const.PENDING,
                                           cc_const.PROCESSING,
                                           True)

    def test_lock_maintenance_fails_when_processing(self):
        self._test_maintenance_lock_unlock(True,
                                           cc_const.PROCESSING,
                                           cc_const.PROCESSING,
                                           False)

    def test_unlock_maintenance(self):
        self._test_maintenance_lock_unlock(False,
                                           cc_const.PROCESSING,
                                           cc_const.PENDING,
                                           True)

    def test_unlock_maintenance_fails_when_pending(self):
        self._test_maintenance_lock_unlock(False,
                                           cc_const.PENDING,
                                           cc_const.PENDING,
                                           False)
