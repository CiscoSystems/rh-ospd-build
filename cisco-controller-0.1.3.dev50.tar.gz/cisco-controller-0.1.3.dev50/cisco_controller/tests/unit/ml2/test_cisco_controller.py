# Copyright (c) 2015 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import logging
from logging import StreamHandler
import mock

from cisco_controller.common import client_vts

from neutron.conf.plugins.ml2 import config
from neutron.plugins.ml2 import plugin
from neutron.tests.unit.plugins.ml2 import test_plugin
from neutron.tests.unit import testlib_api
from oslo_config import cfg
from oslo_log import formatters
from oslo_log import log
from oslo_serialization import jsonutils

cfg.CONF.import_group('ml2_cc', 'cisco_controller.common.config')

HOST = 'fake-host'
PLUGIN_NAME = 'neutron.plugins.ml2.plugin.Ml2Plugin'


def enable_debug_log(print_log=False):
    root_logger = log.getLogger(None).logger
    if print_log:
        handler = StreamHandler()
        handler.setFormatter(formatters.ContextFormatter())
        root_logger.addHandler(handler)
    root_logger.setLevel(logging.DEBUG)


class CiscoControllerConfigBase(test_plugin.Ml2PluginV2TestCase):
    def setUp(self):
        super(CiscoControllerConfigBase, self).setUp()
        config.cfg.CONF.set_override('mechanism_drivers',
                                     ['logger', 'cisco_controller'], 'ml2')
        config.cfg.CONF.set_override('url', 'http://127.0.0.1:9999', 'ml2_cc')
        config.cfg.CONF.set_override('username', 'someuser', 'ml2_cc')
        config.cfg.CONF.set_override('password', 'somepass', 'ml2_cc')
        config.cfg.CONF.set_override('vmm_id', '10', 'ml2_cc')
        # enable_debug_log()


class CiscoControllerTestCase(CiscoControllerConfigBase):
    def setUp(self):
        super(CiscoControllerTestCase, self).setUp()
        self.port_create_status = 'DOWN'
        self.mock_sendjson = mock.patch.object(
            client_vts.VirtualTopologySystemRestClient, 'sendjson').start()
        self.mock_sendjson.side_effect = self.check_sendjson

    def check_sendjson(self, method, urlpath, obj):
        self.assertFalse(urlpath.startswith("http://"))


class CiscoControllerMechanismConfigTests(testlib_api.SqlTestCase):
    def _set_config(self, url='http://127.0.0.1:9999', username='someuser',
                    password='somepass'):
        config.cfg.CONF.set_override('mechanism_drivers',
                                     ['logger', 'cisco_vts'],
                                     'ml2')
        config.cfg.CONF.set_override('url', url, 'ml2_cc')
        config.cfg.CONF.set_override('username', username, 'ml2_cc')
        config.cfg.CONF.set_override('password', password, 'ml2_cc')
        config.cfg.CONF.set_override('vmm_id', '10', 'ml2_cc')

    def _test_missing_config(self, **kwargs):
        self._set_config(**kwargs)
        self.assertRaises(config.cfg.RequiredOptError,
                          plugin.Ml2Plugin)

    def test_valid_config(self):
        self._set_config()
        plugin.Ml2Plugin()

    def test_missing_url_raises_exception(self):
        # TODO(asomya): self._test_missing_config(url=None)
        pass

    def test_missing_username_raises_exception(self):
        # TODO(asomya): self._test_missing_config(username=None)
        pass

    def test_missing_password_raises_exception(self):
        # TODO(asomya): self._test_missing_config(password=None)
        pass


class CiscoControllerMechanismTestBasicGet(test_plugin.TestMl2BasicGet,
                                           CiscoControllerTestCase):
    pass


class CiscoControllerMechanismTestNetworksV2(test_plugin.TestMl2NetworksV2,
                                             CiscoControllerTestCase):
    pass


class CiscoControllerMechanismTestSubnetsV2(test_plugin.TestMl2SubnetsV2,
                                            CiscoControllerTestCase):
    pass


class CiscoControllerMechanismTestPortsV2(test_plugin.TestMl2PortsV2,
                                          CiscoControllerTestCase):
    pass


class DataMatcher(object):

    def __init__(self, operation, object_type, context, modify_cls):
        self._data = context.current.copy()
        self._object_type = object_type
        attr_modify = getattr(modify_cls, 'modify_%s_attributes' % operation)
        self._data = attr_modify(self._data)

    def __eq__(self, s):
        data = jsonutils.loads(s)
        return self._data == data

    def __repr__(self):
        return str(self._data)
