#  Copyright (c) 2016 Cisco Systems, Inc.
#  All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License"); you may
#  not use this file except in compliance with the License. You may obtain
#  a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#  WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#  License for the specific language governing permissions and limitations
#  under the License.
#

import abc
from oslo_log import log as logging

from cisco_controller.common import constants as cc_const
from cisco_controller.journal import journal

from neutron.db import common_db_mixin
from neutron.db import extraroute_db
from neutron.db import l3_agentschedulers_db
from neutron.db import l3_dvr_db
from neutron.db import l3_gwmode_db
from neutron_lib import constants
from neutron_lib.plugins import constants as plugin_constants

LOG = logging.getLogger(__name__)


class CiscoControllerBaseL3RouterPlugin(
    common_db_mixin.CommonDbMixin,
    extraroute_db.ExtraRoute_db_mixin,
    l3_dvr_db.L3_NAT_with_dvr_db_mixin,
    l3_gwmode_db.L3_NAT_db_mixin,
    l3_agentschedulers_db.L3AgentSchedulerDbMixin):

    """Implementation of the Cisco Controller L3 Router Service Plugin.

    This base class implements a L3 service plugin that provides
    router and floatingip resources.
    """
    supported_extension_aliases = ["dvr", "router", "ext-gw-mode",
                                   "extraroute"]

    def __init__(self):
        LOG.debug("Initializing Cisco Controller L3 Service Plugin.")
        self.journal = journal.Journal(self.get_controller_type())

    @abc.abstractmethod
    def get_controller_type(self):
        pass

    def get_plugin_type(self):
        return plugin_constants.L3

    def get_plugin_description(self):
        """Returns string description of the plugin."""
        return ("L3 Router Service Plugin for basic L3 forwarding "
                "using Cisco Controller.")

    def create_router(self, context, router):
        router_dict = super(
            CiscoControllerBaseL3RouterPlugin, self).create_router(
                context, router)
        self.journal.add_event(context.session, cc_const.CC_ROUTER,
                               router_dict['id'], cc_const.CC_CREATE,
                               router_dict)
        return router_dict

    def update_router(self, context, router_id, router):
        router_db = self._get_router(context, router_id)
        original = self._make_router_dict(router_db)
        router_dict = super(
            CiscoControllerBaseL3RouterPlugin, self).update_router(
                context, router_id, router)
        self.journal.add_update_event(context.session, cc_const.CC_ROUTER,
                                      router_id, cc_const.CC_UPDATE,
                                      router_dict, original)
        return router_dict

    def delete_router(self, context, router_id):
        router_dict = self.get_router(context, router_id)
        dependency_list = [router_dict['gw_port_id']]
        super(CiscoControllerBaseL3RouterPlugin, self).delete_router(
            context, router_id)
        self.journal.add_event(context.session, cc_const.CC_ROUTER,
                               router_id, cc_const.CC_DELETE,
                               dependency_list)

    def create_floatingip(self, context, floatingip,
                          initial_status=constants.FLOATINGIP_STATUS_ACTIVE):
        fip_dict = super(
            CiscoControllerBaseL3RouterPlugin, self).create_floatingip(
                context, floatingip, initial_status)
        self.journal.add_event(context.session, cc_const.CC_FLOATINGIP,
                               fip_dict['id'], cc_const.CC_CREATE,
                               fip_dict)
        return fip_dict

    def update_floatingip(self, context, floatingip_id, floatingip):
        floatingip_db = self._get_floatingip(context, floatingip_id)
        original = self._make_floatingip_dict(floatingip_db)
        fip_dict = super(
            CiscoControllerBaseL3RouterPlugin, self).update_floatingip(
                context, floatingip_id, floatingip)

        # Update status based on association
        if fip_dict.get('port_id') is None:
            fip_dict['status'] = constants.FLOATINGIP_STATUS_DOWN
        else:
            fip_dict['status'] = constants.FLOATINGIP_STATUS_ACTIVE
        self.update_floatingip_status(context, floatingip_id,
                                      fip_dict['status'])
        current = self._make_floatingip_dict(floatingip_db)

        self.journal.add_update_event(context.session, cc_const.CC_FLOATINGIP,
                                      floatingip_id, cc_const.CC_UPDATE,
                                      current, original)
        return fip_dict

    def delete_floatingip(self, context, floatingip_id):
        floatingip_dict = self.get_floatingip(context, floatingip_id)
        dependency_list = [floatingip_dict['router_id']]
        dependency_list.append(floatingip_dict['floating_network_id'])
        super(CiscoControllerBaseL3RouterPlugin, self).delete_floatingip(
            context, floatingip_id)
        self.journal.add_event(context.session, cc_const.CC_FLOATINGIP,
                               floatingip_id, cc_const.CC_DELETE,
                               dependency_list)

    def add_router_interface(self, context, router_id, interface_info):
        new_router = super(
            CiscoControllerBaseL3RouterPlugin, self).add_router_interface(
                context, router_id, interface_info)
        router_dict = self._generate_router_dict(router_id, interface_info,
                                                 new_router)
        self.journal.add_event(context.session, cc_const.CC_ROUTER_INTF,
                               cc_const.CC_UUID_NOT_USED,
                               cc_const.CC_ADD, router_dict)
        return new_router

    def remove_router_interface(self, context, router_id, interface_info):
        new_router = super(
            CiscoControllerBaseL3RouterPlugin,
            self).remove_router_interface(context, router_id,
                                          interface_info)
        router_dict = self._generate_router_dict(router_id, interface_info,
                                                 new_router)
        self.journal.add_event(context.session, cc_const.CC_ROUTER_INTF,
                               cc_const.CC_UUID_NOT_USED,
                               cc_const.CC_REMOVE, router_dict)
        return new_router

    def _generate_router_dict(self, router_id, interface_info, new_router):
        # Get network info for the subnet that is being added to the router.
        # Check if the interface information is by port-id or subnet-id.
        add_by_port, add_by_sub = self._validate_interface_info(interface_info)
        if add_by_sub:
            _port_id = new_router['port_id']
            _subnet_id = interface_info['subnet_id']
        elif add_by_port:
            _port_id = interface_info['port_id']
            _subnet_id = new_router['subnet_id']

        router_dict = {'subnet_id': _subnet_id,
                       'port_id': _port_id,
                       'id': router_id,
                       'tenant_id': new_router['tenant_id']}

        return router_dict

    dvr_deletens_if_no_port_warned = False

    def dvr_deletens_if_no_port(self, context, port_id):
        # TODO(yamahata): implement this method or delete this logging
        # For now, this is defined to avoid attribute exception
        # Since CC L3 does not create namespaces, this is always going to
        # be a noop. When it is confirmed, delete this comment and logging
        if not self.dvr_deletens_if_no_port_warned:
            LOG.debug('dvr is not suported yet. '
                      'this method needs to be implemented')
            self.dvr_deletens_if_no_port_warned = True
        return []
