Welcome to cisco-controller's documentation!
========================================================

.. include:: ../../README.rst

Developer Docs
--------------

.. toctree::
   :maxdepth: 1

   devref/index


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

