# Copyright (c) 2015 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import copy
from datetime import datetime
from datetime import timedelta
import time
import traceback

import eventlet
from requests import exceptions

from oslo_concurrency.lockutils import synchronized
from oslo_config import cfg
from oslo_log import log as logging

from cisco_controller.common import config as cc_conf
from cisco_controller.common import constants as cc_const
from cisco_controller.common import password_utils
from cisco_controller.common import utils
from cisco_controller.db import db
from cisco_controller.db import models
from cisco_controller.journal import failure_handler
from cisco_controller.journal import maintenance

from neutron.api.v2.attributes import CORE_RESOURCES
from neutron.db import api as neutron_db_api
from neutron_lib.api import attributes

LOG = logging.getLogger(__name__)
MIN_THRESHOLD = 1


class Journal(object):
    _journal_thread = None

    def __init__(self, controller_type, session=None):
        db_engine = \
            db.db_api.context_manager.get_legacy_facade().get_engine()
        if Journal._journal_thread is not None:
            return
        db.init_db(db_engine, models.JournalTable)
        cfg.CONF.register_opts(cc_conf.cc_opts, "ml2_cc")
        Journal._journal_thread = JournalThread(controller_type,
                                                db_engine)
        mt = self._prepare_maintenance_thread()
        mt.start(db_engine)

    @classmethod
    def process_stalled_events(cls, session):
        """Process stalled events"""
        cls._journal_thread.process_old_events(session)

    @classmethod
    def _prepare_maintenance_thread(cls):
        # start the maintenance thread and register all the maintenance
        # operations :
        # (1) Make sure events that should have been processed by other
        #     processes, but were not, for some reason are processed
        m = maintenance.MaintenanceThread()
        # the only job maintenance thread is performing could be blocking
        # it is calling run_sync_thread, which is synchronized
        m.register_operation(cls.process_stalled_events)
        return m

    def _add_event(self, session, object_type, object_uuid, operation,
                   data, old_data, **kwargs):
        Journal._journal_thread.add_event(session, object_type, object_uuid,
                                          operation, data, old_data, **kwargs)

    def add_event(self, session, object_type, object_uuid, operation,
                  data, **kwargs):
        self._add_event(session, object_type, object_uuid, operation, data,
                        None, **kwargs)

    def _filter_data(self, object_type, data):
        if object_type not in CORE_RESOURCES:
            return data
        collection_name = CORE_RESOURCES[object_type]
        res_info = attributes.RESOURCES[collection_name]

        whitelist = {k for k, v in res_info.items() if
                     v['allow_put'] is True}
        return {k: v for k, v in data.items() if k in whitelist}

    def add_update_event(self, session, object_type, object_uuid,
                         operation, data, old_data, **kwargs):
        self._add_event(session, object_type, object_uuid, operation, data,
                        self._filter_data(object_type, old_data), **kwargs)


class JournalThread(object):
    """Thread worker for the CiscoController Journal Database."""

    def _get_password(self):
        password = cfg.CONF.ml2_cc.password
        try:
            password = password_utils.decrypt(password)
        except password_utils.PasswordIsNotEncrypted:
            pass
        return password

    def __init__(self, controller_type, engine):
        LOG.debug("Initializing Journaling thread from:\n%s",
                  traceback.format_stack())
        self.client = controller_type['driver'](
            cfg.CONF.ml2_cc.url,
            cfg.CONF.ml2_cc.username,
            self._get_password(),
            cfg.CONF.ml2_cc.timeout
        )
        self._cc_sync_timeout = cfg.CONF.ml2_cc.sync_timeout
        self._row_retry_count = cfg.CONF.ml2_cc.retry_count
        if self._row_retry_count < 0:
            self._row_retry_count = 1
        self.max_batch = cfg.CONF.ml2_cc.max_batch
        self._modify_map = controller_type['utils'].MODIFY_MAP
        self._http_method_map = controller_type['utils'].HTTP_METHOD_MAP
        self._url_path_map = controller_type['utils'].URL_PATH_MAP
        self.engine = engine
        self.last_time = time.clock() - MIN_THRESHOLD
        self.process_thread = None
        self.ports_in_processing = set()
        self.port_processing = eventlet.GreenPool(
            cfg.CONF.ml2_cc.max_concurrent_vts_events)
        self.first_non_port = None

    # used by unit testing
    def wait_processing(self):
        if self.process_thread is None:
            return
        if self.process_thread.dead:
            return
        self.process_thread.wait()
        self.port_processing.waitall()

    def process_old_events(self, session):
        def log_msg(oldest):
            txt = ("Oldest event %(type)s %(operation)s, id %(id)s."
                   "Timeout time is: %(time)s, Now is: %(now)s. Processing "
                   "timeout is %(timeout)d, last_retried: %(last_retried)s")
            params = {'type': oldest.object_type,
                      'operation': oldest.operation,
                      'id': oldest.object_uuid,
                      'time': str(timeout),
                      'now': datetime.now(),
                      'timeout': cfg.CONF.ml2_cc.processing_timeout,
                      'last_retried': str(oldest.last_retried)}
            return txt % params

        oldest = db.get_ordered_rows(session).first()
        if oldest is None:
            LOG.debug("No events in the journaling DB")
            return
        timeout = (oldest.last_retried +
                   timedelta(seconds=cfg.CONF.ml2_cc.processing_timeout))
        if timeout > datetime.now():
            LOG.debug("%s. No stalled entries", log_msg(oldest))
            return

        LOG.info(
            "%s. Oldest event wasn't processed, processing events now",
            log_msg(oldest))
        self.run_sync_thread()

    def add_event(self, session, object_type, object_uuid, operation,
                  data, old_data, **kwargs):
        try:
            vtc_data = self._json_data(operation, object_type, data)
        except utils.NoTenantName:
            LOG.debug("No tenant info skipping the event %s %s %s",
                      operation, object_type, object_uuid)
            return

        # if there are no entries in the DB, reset the id
        reset = db.get_ordered_rows(session).count() == 0
        if not reset:
            row = db.create_row(session, object_type, object_uuid,
                                operation, vtc_data, data, old_data, **kwargs)
            LOG.debug("There are events when adding %s %s, id: %s",
                      object_type, object_uuid, repr(row.id))
            return

        LOG.debug("try to reset when adding %s %s", object_type, object_uuid)
        row = db.create_row_w_reset(session, object_type, object_uuid,
                                    operation, vtc_data, data, old_data,
                                    **kwargs)
        # in HA case first row isn't always '1', even if we reset it to 1
        first_row = db.get_ordered_rows(session).first()
        if row == first_row:
            # even in case we reset the id, other process could add a row
            # before we do, so only in case we are first we should trigger
            # the thread
            LOG.debug("Notifying the thread when adding %s %s",
                      object_type, object_uuid)
            self.process_thread = eventlet.spawn(self.run_sync_thread)
        else:
            LOG.debug("NOT Notifying the thread when adding %s %s, id: %s",
                      object_type, object_uuid, repr(row.id))

    def _json_data(self, operation, object_type, data):

        if operation == cc_const.CC_DELETE:
            return None
        modify_cls = self._modify_map[object_type]
        attr_modify = getattr(modify_cls,
                              'modify_%s_attributes' % operation)
        data_copy = copy.deepcopy(data)
        return attr_modify(data_copy)

    @staticmethod
    def log_details(row, trace=False):
        return (("\n%(type)s %(operation)s, id %(uuid)s." +
                 ("\n%(trace)s" if trace else "")) %
                {'type': row.object_type,
                 'uuid': row.object_uuid,
                 'operation': row.operation,
                 'trace': traceback.format_exc()})

    # synchronized to make sure maintenance thread running on the same
    # controller will not do the same job if there's some delays
    @synchronized('cisco_jthread', external=True)
    def run_sync_thread(self):
        def thread_log_details():
            return "\n%s" % traceback.format_exc()
        LOG.debug("Starting the journaling processing thread")
        session = neutron_db_api.get_writer_session()

        now = time.clock()
        if now - self.last_time < MIN_THRESHOLD:
            # throttle the run
            eventlet.sleep(MIN_THRESHOLD - (now - self.last_time))
        first_run = True
        has_events = True
        while True:
            try:
                # we want to limit the number of events in transmission,
                # because if there's a crash, then this is the maximum
                # number of events that will be resend, in addition to
                # other reasons for limiting the query
                LOG.debug("Quering for journaling entries, except ports %s",
                          self.ports_in_processing)
                rows = db.get_ordered_rows(
                    session, limit=self.max_batch,
                    wo_port_ids=self.ports_in_processing).all()
                total = db.get_ordered_rows(session).count()
                rows_count = len(rows)
                if rows_count == 0:
                    if not has_events and self.port_processing.running() == 0:
                        LOG.debug("No more events to process")
                        break

                    has_events = False
                    LOG.debug("No more events to process, in order to "
                              "accomodate race conditions between deleting "
                              "the last event and resetting the id key will "
                              "retry one last time, after a delay")
                    if self.port_processing.running():
                        LOG.debug("Waiting for port processing to finish")
                        self.port_processing.waitall()
                    eventlet.sleep(MIN_THRESHOLD)
                    continue
                has_events = True

                # if first row id is reset, this means other thread
                # was triggered
                if not first_run and rows[0].id == models.INITIAL_AUTOINC_NUM:
                    LOG.debug("row.id was reset, while processing, meaning "
                              "other thread was triggered - aborting, "
                              "event is: %s",
                              self.log_details(rows[0]))
                    self.port_processing.waitall()
                    break
                LOG.debug("Processing %d events%s", rows_count,
                          (", out of %d total events" % total) if
                          total > rows_count else "")
                error = self._sync_pending_rows(session, rows)
                if error:
                    # wait a little before retrying
                    eventlet.sleep(MIN_THRESHOLD)
                    continue
                first_run = False

            except Exception:
                # Catch exceptions to protect the thread while running
                LOG.warning("run_sync_thread caught unexpected "
                            "exception, continuing.%s",
                            thread_log_details())

        self.last_time = time.clock()
        LOG.debug("Finished the journaling processing thread")

    def _finish_row_processing(self, session, row, success):
        db.delete_row(session, row.id)
        if row.id == self.first_non_port:
            self.first_non_port = None
        if success:
            utils.post_row_operation_methods(row)
        else:
            failure_handler.handle(row)

    # returns False if the event wasn't processed
    def _sync_row(self, session, row):
        try:
            start = time.time()
            method = self._http_method_map[row.operation]
            urlpath_def = self._url_path_map[row.operation]
            url_object = row.object_type.replace('_', '-')
            urlpath = urlpath_def(url_object, row)
            self.client.sendjson(method, urlpath, row.vtc_data,
                                 object_type=row.object_type)
            stop = time.time()
            LOG.info("Successfully synced in %(time).2f "
                     "seconds.%(details)s",
                     {'time': stop - start,
                      'details': self.log_details(row)})
            # Success, remove the entry
            self._finish_row_processing(session, row, success=True)
            return True
        except exceptions.ConnectionError:
            # Don't raise the retry count, just log an error
            LOG.error("Cannot connect to the Controller.%s",
                      self.log_details(row, trace=True))
            db.update_last_retried(session, row)
            # We should retry the operation at a later time
            return False
        except exceptions.RetryError:
            # Don't retry this row, mark it failed
            LOG.info("Attempted operation was not found on the server."
                     "Marking as failed without retries.%s",
                     self.log_details(row, trace=True))
            # Failure, remove the entry
            self._finish_row_processing(session, row, success=False)
            return True

        except Exception:
            remaining_retries = (self._row_retry_count -
                                 db.inc_db_row_retry(session, row))
            if remaining_retries > 0:
                LOG.warning("Error syncing, will retry %(remaining)d"
                            " more times.%(details)s",
                            {'remaining': remaining_retries,
                             'details': self.log_details(row, trace=True)})
                db.update_last_retried(session, row)
                # We should retry the operation at a later time
                return False
            LOG.error("Error syncing, will not retry.%s",
                      self.log_details(row, trace=True))
            # Failure, remove the entry
            self._finish_row_processing(session, row, success=False)
            return True

    @staticmethod
    def _get_first_non_port_row_id(session):
        row = db.get_ordered_rows(session,
                                  not_obj_type=cc_const.CC_PORT).first()
        if row is None:
            return None
        return row.id

    def _port_rows_process_thread(self, session, port_id):
        # protection in case of id reset (used to allow
        # a different process to handle communication)
        last_id = 0
        events_counter = 0
        while True:
            row = db.get_ordered_rows(session, port_id=port_id).first()
            if row is None:
                LOG.debug("No more events for port_id %s.", port_id)
                break
            if row.id < last_id:
                LOG.debug("Other thread will process events for port_id %s.",
                          port_id)
                break
            if self.first_non_port is None:
                self.first_non_port = self._get_first_non_port_row_id(session)
                if self.first_non_port is not None:
                    LOG.debug("There's a new non-port event at id: %d.",
                              self.first_non_port)
            if self.first_non_port is not None and \
               row.id > self.first_non_port:
                LOG.debug("Ending port thread processing because of non-port "
                          "event at id: %d, port event id: %d.",
                          self.first_non_port, row.id)
                break
            last_id = row.id
            if self._sync_row(session, row):
                events_counter += 1
        self.ports_in_processing.remove(port_id)
        LOG.debug("Finished processing thread for port_id %s, "
                  "processed %d events", port_id, events_counter)

    def _process_port_row(self, session, row):
        port_id = row.object_uuid
        if port_id in self.ports_in_processing:
            return
        self.ports_in_processing.add(port_id)
        LOG.debug("Spawning processing thread for port_id %s", port_id)
        self.port_processing.spawn(self._port_rows_process_thread,
                                   session, port_id)

    # returns whether there was an error processing the entries
    def _sync_pending_rows(self, session, rows):
        # if breaked out of the loop, then there's an error
        count_processed = 0
        for row in rows:
            if row.object_type == cc_const.CC_PORT:
                self._process_port_row(session, row)
                continue
            # block till all ports are processed
            # when there's non-port event, all threads will exit before
            # processing events after the non-port event (avoid dependency)
            LOG.debug("Waiting for all ports processing to finish, there are "
                      "%d greenlets", self.port_processing.running())
            self.port_processing.waitall()
            if not self._sync_row(session, row):
                has_error = True
                break
            count_processed += 1
        else:
            has_error = False

        LOG.debug("Processed %d non port events, ended with %s",
                  count_processed, 'an error' if has_error else 'success')
        return has_error
