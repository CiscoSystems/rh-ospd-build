# Copyright (c) 2017 cisco Systems Inc.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import abc

from cisco_controller.common import constants as cc_const
from oslo_log import log as logging

from neutron.db import api as db_api
from neutron.db.models import securitygroup
from neutron_lib.callbacks import events
from neutron_lib.callbacks import registry
from neutron_lib.callbacks import resources

LOG = logging.getLogger(__name__)


RESOURCE_TO_EVENT = {events.AFTER_CREATE: cc_const.CC_CREATE,
                     events.AFTER_UPDATE: cc_const.CC_UPDATE,
                     events.BEFORE_DELETE: cc_const.CC_DELETE}


class SecurityGroupDriver(object):
    def __init__(self, journal):

        LOG.info("Initializing Security Group Plugin.")
        self.session = db_api.get_writer_session()
        self.journal = journal
        # SG
        registry.subscribe(self.security_group_event_handle,
                           resources.SECURITY_GROUP,
                           events.AFTER_CREATE)
        registry.subscribe(self.security_group_event_handle,
                           resources.SECURITY_GROUP,
                           events.AFTER_UPDATE)
        registry.subscribe(self.security_group_event_handle,
                           resources.SECURITY_GROUP,
                           events.BEFORE_DELETE)

        # SGR
        registry.subscribe(self.security_group_rule_event_handle,
                           resources.SECURITY_GROUP_RULE,
                           events.AFTER_CREATE)
        registry.subscribe(self.security_group_rule_event_handle,
                           resources.SECURITY_GROUP_RULE,
                           events.BEFORE_DELETE)

    def security_group_event_handle(self, resource, event, trigger, **kwargs):
        LOG.info(
            "Event %(event)s for %(resource)s triggered w/ payload %(data)s",
            {'event': event, 'resource': resource, 'data':
                str(kwargs['security_group'])})

        self.journal.add_event(self.session, resource,
                               kwargs['security_group']['id'],
                               RESOURCE_TO_EVENT[event],
                               kwargs['security_group'])

        LOG.info(
            "Created new row for %(resource)s a %(event)s event in Journal "
            "table.", {'resource': resource, 'event': event})

    def security_group_rule_event_handle(self, resource, event, trigger,
                                         **kwargs):
        LOG.info(
            "Event: %(event)s for %(resource)s triggered with payload "
            "%(data)s", {'event': event, 'resource': resource, 'data': str(
                kwargs)})
        if event == events.BEFORE_DELETE:
            sgr_id = str(kwargs['security_group_rule_id'])
            sg_parent_res_id = self.session.query(
                securitygroup.SecurityGroupRule) \
                .filter_by(id=sgr_id).one()
            LOG.info("Retrieved parent %(SG)s id from neutron for deleted "
                     "SGR: %(SGR)s", {'SG': str(sg_parent_res_id),
                                      'SGR': sgr_id})
            kwargs['security_group_rule'] = sg_parent_res_id
        self.journal.add_event(self.session, resource,
                               kwargs['security_group_rule']['id'],
                               RESOURCE_TO_EVENT[event],
                               kwargs['security_group_rule'])
        LOG.info(
            "Created new row for %(resource)s %(event)s event in Journal "
            "table.", {'resource': resource, 'event': event})

    @abc.abstractmethod
    def get_controller_type(self):
        pass

    @classmethod
    def create(cls, journal):
        return SecurityGroupDriver(journal)


def register(journal):
    """Register the Security group driver."""
    SecurityGroupDriver.create(journal)
    LOG.info("VTS security groups driver registered")
