# Copyright (c) 2015 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import six
import sqlalchemy as sa

from cisco_controller.common import constants as cc_const

from neutron_lib.db import model_base
from oslo_serialization import jsonutils


INITIAL_AUTOINC_NUM = 1


class JsonType(sa.types.TypeDecorator):
    # Text type only supports maximum length of 65KB. It is being extended
    # to Medium Text type which can support upto 16MB for large payloads
    # in the data column of ciscocontrollerjournal table.
    impl = sa.types.Text(80000)

    def process_bind_param(self, value, engine):
        return six.u(jsonutils.dumps(value))

    def process_result_value(self, value, engine):
        if not value:
            return {}
        return jsonutils.loads(value.replace('\r\n', ''))

    @property
    def python_type(self):
        if self.convert_unicode:
            return sa.util.ext_type
        else:
            return str


class JournalTable(model_base.BASEV2):
    __tablename__ = 'ciscocontrollerjournal'

    id = sa.Column(sa.Integer, autoincrement=True, primary_key=True)
    object_type = sa.Column(sa.String(36), nullable=False)
    object_uuid = sa.Column(sa.String(36), nullable=False)
    operation = sa.Column(sa.String(36), nullable=False)
    data = sa.Column(JsonType, nullable=True)
    vtc_data = sa.Column(JsonType, nullable=True)
    old_data = sa.Column(JsonType, nullable=True)
    provision = sa.Column(sa.Boolean)
    retry_count = sa.Column(sa.Integer, default=0)
    created_at = sa.Column(sa.DateTime)
    last_retried = sa.Column(sa.TIMESTAMP, server_default=sa.func.now(),
                             onupdate=sa.func.now(), index=True)


class MaintenanceTable(model_base.BASEV2, model_base.HasId):
    __tablename__ = 'ciscocontroller_maintenance'

    state = sa.Column(sa.Enum(cc_const.PENDING, cc_const.PROCESSING),
                      nullable=False)
    node_name = sa.Column(sa.String(120))
    processing_operation = sa.Column(sa.String(70))
    lock_updated = sa.Column(sa.TIMESTAMP, nullable=False,
                             server_default=sa.func.now(),
                             onupdate=sa.func.now())
