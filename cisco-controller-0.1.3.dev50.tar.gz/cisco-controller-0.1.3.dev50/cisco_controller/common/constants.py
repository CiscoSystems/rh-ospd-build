# Copyright (c) 2015 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

CC_NETWORK = 'network'
CC_NETWORKS = 'networks'
CC_SUBNET = 'subnet'
CC_SUBNETS = 'subnets'
CC_PORT = 'port'
CC_PORTS = 'ports'
CC_SG = 'security_group'
CC_SGS = 'security_groups'
CC_SG_RULE = 'security_group_rule'
CC_SG_RULES = 'security_group_rules'
CC_ROUTER = 'router'
CC_ROUTER_INTF = 'router_interface'
CC_FLOATINGIP = 'floatingip'
CC_TRUNK = 'trunk'

CC_L2_OBJECT_TYPES = [CC_NETWORK, CC_SUBNET, CC_PORT]

CC_LOADBALANCER = 'loadbalancer'
CC_LOADBALANCERS = 'loadbalancers'
CC_LISTENER = 'listener'
CC_LISTENERS = 'listeners'
CC_POOL = 'pool'
CC_POOLS = 'pools'
CC_MEMBER = 'member'
CC_MEMBERS = 'members'
CC_HEALTHMONITOR = 'healthmonitor'
CC_HEALTHMONITORS = 'healthmonitors'

CC_CREATE = 'create'
CC_UPDATE = 'update'
CC_DELETE = 'delete'
CC_ADD = 'add'
CC_REMOVE = 'remove'

CC_UUID_NOT_USED = '0'

# Constants for journal operation states
PENDING = 'pending'
PROCESSING = 'processing'
FAILED = 'failed'
COMPLETED = 'completed'

# Constants for VTS uri's
XRVR_SYNC_URI = '/api/running/devices/device/%s/_operations/sync-from'

# Nova endpoint constants
NOVA_API_VERSION = '2'
