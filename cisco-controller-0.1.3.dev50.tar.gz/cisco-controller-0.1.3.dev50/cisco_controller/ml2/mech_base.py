# Copyright (c) 2013-2016 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import abc

from oslo_log import log as logging

from neutron_lib import constants
from neutron_lib.plugins.ml2 import api

from cisco_controller.common import constants as cc_const
from cisco_controller.journal import journal

LOG = logging.getLogger(__name__)


class CiscoControllerBaseMechanismDriver(api.MechanismDriver):
    """Cisco Controller base driver.

    This code is the base class backend implementation for the Cisco
    Controller ML2 MechanismDriver for OpenStack Neutron.
    """
    def initialize(self):
        LOG.debug("Initializing Cisco Controller ML2 driver")
        self.journal = journal.Journal(self.get_controller_type())

    @abc.abstractmethod
    def get_controller_type(self):
        pass

    def should_send_event(self, object_type, operation, data):
        return True

    def create_network_postcommit(self, context):
        if not self.should_send_event(cc_const.CC_NETWORK,
                                      cc_const.CC_CREATE,
                                      context.current):
            return False
        self.journal.add_event(context._plugin_context.session, 'network',
                               context.current['id'], 'create',
                               context.current)
        return True

    def create_subnet_postcommit(self, context):
        if not self.should_send_event(cc_const.CC_SUBNET,
                                      cc_const.CC_CREATE,
                                      context.current):
            return False
        self.journal.add_event(context._plugin_context.session, 'subnet',
                               context.current['id'], 'create',
                               context.current)
        return True

    def create_port_postcommit(self, context, provision=False):
        if not self.should_send_event(cc_const.CC_PORT,
                                      cc_const.CC_CREATE,
                                      context.current):
            return False

        self.journal.add_event(context._plugin_context.session, 'port',
                               context.current['id'], 'create',
                               context.current, provision=provision)
        return True

    def update_network_postcommit(self, context):
        if not self.should_send_event(cc_const.CC_NETWORK,
                                      cc_const.CC_UPDATE,
                                      context.current):
            return False
        self.journal.add_update_event(context._plugin_context.session,
                                      'network', context.current['id'],
                                      'update', context.current,
                                      context.original)

        return True

    def update_subnet_postcommit(self, context):
        if not self.should_send_event(cc_const.CC_SUBNET,
                                      cc_const.CC_UPDATE,
                                      context.current):
            return False
        self.journal.add_update_event(context._plugin_context.session,
                                      'subnet', context.current['id'],
                                      'update', context.current,
                                      context.original)
        return True

    @staticmethod
    def _should_skip_port_update(port):
        device_owner = port.get('device_owner')
        return device_owner in {None,
                                'network:router_interface',
                                'network:router_gateway'}

    def update_port_postcommit(self, context, provision=False):
        if not self.should_send_event(cc_const.CC_PORT,
                                      cc_const.CC_UPDATE,
                                      context.current):
            return False
        self.journal.add_update_event(context._plugin_context.session, 'port',
                                      context.current['id'], 'update',
                                      context.current, context.original,
                                      provision=provision)
        return True

    def delete_network_postcommit(self, context):
        if not self.should_send_event(cc_const.CC_NETWORK,
                                      cc_const.CC_DELETE,
                                      context.current):
            return False
        self.journal.add_event(context._plugin_context.session, 'network',
                               context.current['id'], 'delete',
                               None)
        return True

    def delete_subnet_postcommit(self, context):
        if not self.should_send_event(cc_const.CC_SUBNET,
                                      cc_const.CC_DELETE,
                                      context.current):
            return False
        self.journal.add_event(context._plugin_context.session, 'subnet',
                               context.current['id'], 'delete',
                               context.current)
        return True

    def delete_port_postcommit(self, context):
        if not self.should_send_event(cc_const.CC_PORT,
                                      cc_const.CC_DELETE,
                                      context.current):
            return False
        self.journal.add_event(context._plugin_context.session, 'port',
                               context.current['id'], 'delete',
                               context.current)
        return True

    def get_allowed_network_types(self, agent):
        return {constants.TYPE_LOCAL, constants.TYPE_GRE,
                constants.TYPE_VXLAN, constants.TYPE_VLAN,
                constants.TYPE_FLAT}

    def get_mappings(self, agent):
        return agent['configurations'].get('device_mappings', {})

    def check_segment_for_agent(self, segment, agent=None):
        """Check if segment can be bound.

        :param segment: segment dictionary describing segment to bind
        :param agent: agents_db entry describing agent to bind or None
        :returns: True if segment can be bound for agent
        """
        network_type = segment[api.NETWORK_TYPE]
        if network_type not in self.get_allowed_network_types(agent):
            return False
        if not agent:
            return True
        mappings = self.get_mappings(agent)
        LOG.debug("Checking segment: %(segment)s "
                  "for mappings: %(mappings)s ",
                  {'segment': segment, 'mappings': mappings})
        return segment[api.PHYSICAL_NETWORK] in mappings
