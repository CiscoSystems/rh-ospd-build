Welcome!
========

This is the external, decomposed plugin library for the VTS ML2
MechanismDriver. This is the backend code which handles communication with
VTS.

External Resources:
===================

The Neutron homepage:
   http://launchpad.net/neutron.
