# Copyright (c) 2016 Cisco Systems, Inc.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import mock
import requests

from cisco_controller.common import utils
from cisco_controller.db import db
from cisco_controller.journal import failure_handler
from cisco_controller.journal.journal import Journal
from cisco_controller.ml2 import mech_vts
from cisco_controller.tests.unit.ml2 import test_cisco_controller
from cisco_controller.trunk import driver

from keystoneauth1.identity import generic
from keystoneauth1 import session
from neutron.db import api as neutron_db_api
from neutron.objects import trunk as trunk_objects
from neutron.services.trunk.callbacks import TrunkPayload
from neutron.services.trunk import constants as trunk_consts
from neutron_lib.callbacks import events
from neutron_lib.callbacks import registry
from neutronclient.v2_0 import client as neutronclient_v2

from oslo_utils import uuidutils


_uuid = uuidutils.generate_uuid
trunk_id = _uuid()
TEST_TENANT_NAME = 'tenant_name'

sub_ports_curr = [trunk_objects.SubPort
                  (context=None,
                   port_id='7b0b905e-b2ce-4231-b84a-71063997960a',
                   segmentation_id='1007',
                   segmentation_type='vlan')]

sub_ports_orig = [trunk_objects.SubPort
                  (context=None,
                   port_id='6a0b905e-b2ce-4231-b84a-71063997960a',
                   segmentation_id='1006',
                   segmentation_type='vlan')]

payload = TrunkPayload(context=None,
                       trunk_id=trunk_id,
                       current_trunk={'tenant_id': 'test-tenant',
                                      'name': 'test_trunk',
                                      'port_id': 'test_parent_port',
                                      'sub_ports': sub_ports_curr},
                       original_trunk={'tenant_id': 'test-tenant',
                                       'sub_ports': sub_ports_orig},
                       subports=sub_ports_curr)


class CiscoControllerVTSTrunkTestCase(
        test_cisco_controller.CiscoControllerConfigBase):

    def _request_mock(self, *args, **kwargs):
        return self.request_response

    def _create_session(self):
        auth = generic.Password('')
        return session.Session(auth=auth)

    def setUp(self):
        super(CiscoControllerVTSTrunkTestCase, self).setUp()
        self.db_session = neutron_db_api.get_writer_session()
        self._session = self._create_session()
        mock.patch.object(utils,
                          '_get_tenant_name',
                          return_value=TEST_TENANT_NAME).start()

        self.request_response = self._get_mock_request_response(200)
        self.request_mock = mock.patch.object(
            requests, 'request', side_effect=self._request_mock).start()
        mock.patch.object(utils, '_get_session',
                          return_value=self._session).start()
        self.addCleanup(self._db_cleanup)
        mock.patch.object(Journal, '_prepare_maintenance_thread').start()
        self.mech = mech_vts.CiscoControllerVTSMechanismDriver()
        self.mech.initialize()
        self.thread = self.mech.journal._journal_thread

    def tearDown(self):
        super(CiscoControllerVTSTrunkTestCase, self).tearDown()
        Journal._journal_thread = None

    def _db_cleanup(self):
        rows = db.get_all_db_rows(self.db_session)
        for row in rows:
            db.delete_row(self.db_session, exact_id=row.id)

    def _wait_processing(self):
        self.thread.wait_processing()

    # This function verifies the db rows after entry is made
    def _test_db_results(self, operation):
        rows = db.get_all_db_rows(self.db_session)

        self.assertEqual(1, len(rows))
        self.assertEqual(operation, rows[0]['operation'])
        self.assertEqual(trunk_consts.TRUNK, rows[0]['object_type'])
        self.assertEqual(trunk_id, rows[0]['object_uuid'])

    # This function makes a call to the method which is 'run_sync_thread'
    # in this case. It mocks a response and verifies if the requests.request
    # was called. Since sendjson is mocked in the super class, no call to
    # VTC will be made eventually.
    def _test_operation(self, expected_calls):
        self.assertEqual(expected_calls, self.request_mock.call_count)
        self.request_mock.reset_mock()

    # This function invokes the send_data in the driver class
    # send_data function adds a row in the db.Then it verifies
    # the db entry.
    def _create_database_entry(self, event, object_type):
        registry.notify(object_type,
                        event, None,
                        payload=payload)
        if object_type is trunk_consts.SUBPORTS:
            event = events.AFTER_UPDATE

        self._test_db_results(driver.RESOURCE_TO_EVENT[event])

    # This function converts the TrunkPayload class object
    # to dict format
    def _payload_to_dict(self, p):
        return {'trunk_id': p.trunk_id,
                'current_trunk': p.current_trunk,
                'original_trunk': p.original_trunk,
                'subports': p.subports}

    # This function creates a mock response for the
    # requests.request function depending on the status code.
    def _get_mock_request_response(cls, status_code):
        response = mock.Mock(status_code=status_code)
        response.raise_for_status = mock.Mock() if status_code < 400 else (
            mock.Mock(side_effect=requests.exceptions.HTTPError(
                cls._status_code_msgs[status_code])))
        return response

    def _getUrl(self, base_url, path):
        return base_url + path

    # This function creates a db entry, then prepares the url, payload
    # needed when run_sync_thread is called. run_sync_thread retrieves
    # the jorunal db entry and processes it
    def _create_db_entry_and_process_it(self, event, object_type,
                                        expected_calls=1,
                                        status_code=None):
        status_codes = {events.AFTER_CREATE: requests.codes.created,
                        events.AFTER_UPDATE: requests.codes.ok,
                        events.AFTER_DELETE: requests.codes.no_content}

        operation = driver.RESOURCE_TO_EVENT[event]
        status_code = status_code or status_codes[operation]
        self.request_response = self._get_mock_request_response(status_code)

        # Add an entry in the db with the particular event and object type
        self._create_database_entry(event, object_type)
        self._wait_processing()
        self._test_operation(expected_calls)

    # This function creates a databse entry with error code 400
    # so that the journal thread can process it then call the
    # appropriate mock function
    def _test_object_failure(self, object_type, event, mock_func):
        # Create object_type database row and process. This results in all
        self.thread._row_retry_count = 1
        objs_count = 1
        self._create_db_entry_and_process_it(event, object_type,
                                             expected_calls=objs_count,
                                             status_code=400)

        # Verify that all objects are now marked as failed,
        # and operations reverted
        self.assertEqual(objs_count, mock_func.call_count)
        return mock_func.call_count

    # This function creates a db row with success status code for a given
    # operation and object_type.
    def _test_object_success(self, object_type, event):
        # Create object_type database row and process. This results in all
        self.thread._row_retry_count = 1
        objs_count = 1
        self._create_db_entry_and_process_it(event, object_type,
                                             expected_calls=objs_count,
                                             status_code=200)
    _status_code_msgs = {
        200: '',
        201: '',
        204: '',
        400: '400 Client Error: Bad Request',
        401: '401 Client Error: Unauthorized',
        403: '403 Client Error: Forbidden',
        404: '404 Client Error: Not Found',
        409: '409 Client Error: Conflict',
        501: '501 Server Error: Not Implemented',
        503: '503 Server Error: Service Unavailable',
    }

    def _test_db_to_payload_conversion(self, event, object_type):
        self._create_database_entry(event, object_type)
        rows = db.get_all_db_rows(self.db_session)
        row = rows[0]
        data = self.thread._json_data(row.operation, row.object_type, row.data)
        self.assertEqual('test_trunk', data['trunk']['name'])
        self.assertEqual('test_parent_port', data['trunk']['port-id'])
        self.assertEqual('tenant_name', data['trunk']['tenant-name'])

        for s in data['trunk']['sub-ports']:
            self.assertEqual('cisco-vts-identities:vlan',
                             s['segmentation-type'])

    def test_trunk_create_success(self):
        self._test_object_success(trunk_consts.TRUNK, events.AFTER_CREATE)

    def test_trunk_delete_success(self):
        self._test_object_success(trunk_consts.TRUNK, events.AFTER_DELETE)

    def test_trunk_update_success(self):
        self._test_object_success(trunk_consts.TRUNK, events.AFTER_UPDATE)

    def test_subport_set_success(self):
        self._test_object_success(trunk_consts.SUBPORTS, events.AFTER_CREATE)

    def test_subport_unset_success(self):
        self._test_object_success(trunk_consts.SUBPORTS, events.AFTER_DELETE)

    def test_trunk_create_failure(self):
        self._test_object_failure(trunk_consts.TRUNK, events.AFTER_CREATE,
                                  mock.patch.object(neutronclient_v2.Client,
                                                    'delete_trunk').start())

    def test_trunk_delete_failure(self):
        self._test_object_failure(trunk_consts.TRUNK, events.AFTER_DELETE,
                                  mock.patch.object(failure_handler, 'handle').
                                  start())

    def test_trunk_update_failure(self):
        self._test_object_failure(trunk_consts.TRUNK, events.AFTER_UPDATE,
                                  mock.patch.object(failure_handler, 'handle').
                                  start())

    def test_subport_set_failure(self):
        mock.patch.object(neutronclient_v2.Client,
                          'trunk_add_subports').start()
        self._test_object_failure(trunk_consts.SUBPORTS, events.AFTER_CREATE,
                                  mock.patch.object(neutronclient_v2.Client,
                                                    'trunk_remove_subports').
                                  start())

    def test_subport_unset_failure(self):
        self._test_object_failure(trunk_consts.SUBPORTS, events.AFTER_DELETE,
                                  mock.patch.object(neutronclient_v2.Client,
                                                    'trunk_add_subports').
                                  start())

    def test_payload_sent(self):
        self._test_db_to_payload_conversion(events.AFTER_CREATE,
                                            trunk_consts.TRUNK)
