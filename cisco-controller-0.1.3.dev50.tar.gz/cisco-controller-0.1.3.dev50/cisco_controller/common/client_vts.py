# Copyright (c) 2016 Cisco Systems, Inc.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import re

from oslo_config import cfg
from oslo_log import log as logging
from oslo_serialization import jsonutils
import requests
import six
from webob import exc as wexc

from cisco_controller.common import constants

LOG = logging.getLogger(__name__)

MSG_LOG = "%(method)s %(url)s (%(headers)s): Outgoing data: %(data)s"

# Neutron attibutes to exclude. "_" characters in Neutron attribute names
# need to be substituted with "-".
EXCLUDES = {"project-id", "is-default", "availability-zones", "updated-at",
            "created-at", "revision-number", "tags", "description",
            "ipv4-address-scope", "port-security-enabled", "extra-dhcp-opts",
            "migrating-to", "gw-port-id", "ha", "ha-vr-id"}

SG_EXCLUDES = {"created_at", "updated_at", "project_id",
               "revision_number", "security-group-id",
               "standard-attr", "standard-attr-id"}


def filter_excludes(data, exclude_list=EXCLUDES):
    if not isinstance(data, (dict, list)):
        return data, None
    if isinstance(data, list):
        fl, el = [], []
        for obj in data:
            f, e = filter_excludes(obj, exclude_list)
            fl.append(f)
            if e:
                el.append(e)
        return fl, el
    fd, ed = {}, {}
    for key, obj in six.iteritems(data):
        if key in exclude_list:
            ed[key] = obj
            continue
        fd[key], e = filter_excludes(obj, exclude_list)
        if e:
            ed[key] = e
    return fd, ed


class VirtualTopologySystemRestClient(object):
    def __init__(self, url, username, password, timeout):
        self.url = url
        self.timeout = timeout
        self.auth = (username, password)
        self.force_sync_xrvr = cfg.CONF.ml2_cc.force_sync_xrvr
        self.vmm_path = 'vmm/' + cfg.CONF.ml2_cc.vmm_id
# Deleting the self.cert and self.key configs as
# they are not supported on Newton
# If for VTS client side certificate has to be implemented
# we would need to add the code

    def _send_request(self, method, obj, urlpath, sync_force, object_type):
        headers = {'Content-Type': 'application/vnd.yang.data+json'}
        if obj is not None:
            if (object_type == constants.CC_SG or
                    object_type == constants.CC_SG_RULE):
                filtered, excluded = filter_excludes(obj, SG_EXCLUDES)
            else:
                filtered, excluded = filter_excludes(obj)
            LOG.debug("VTS Filter excluded: %s", repr(excluded))
            data = jsonutils.dumps(filtered, indent=2)
        else:
            data = None

        url_list = [urlpath] if sync_force else [self.url, self.vmm_path,
                                                 urlpath]
        url = '/'.join(url_list)

        request_params = dict(url=url, headers=headers, data=data,
                              auth=self.auth, timeout=self.timeout,
                              verify=False)

        # Log outgoing data
        LOG.debug(MSG_LOG,
                  {'method': method, 'url': url, 'headers': headers,
                   'data': str(data)})
        return requests.request(method, **request_params)

    def sendjson(self, method, urlpath, obj, sync_force=False,
                 object_type=None):
        if not self.url:
            LOG.error("URL path not set. Request not sent.")
            return

        r = self._send_request(method, obj, urlpath, sync_force, object_type)
        self._check_http_response(r, sync_force, method)

    def _check_http_response(self, response, sync_force, method):
        if response.status_code > 300:
            LOG.error("Error code %(code)s response (%(response)s)",
                      {'code': response.status_code,
                       'response': response.text})
        else:
            LOG.debug("Got response (%(response)s)",
                      {'response': response.text})

        if response.status_code == wexc.HTTPConflict.code:
            self._handle_db_locked_error(response)

        if response.status_code > 300 and self.force_sync_xrvr:
            self._handle_xrvr_out_of_sync_error(response, sync_force)

        if (response.status_code == wexc.HTTPNotFound.code and
                method.lower() == constants.CC_DELETE and not response.text):
            raise requests.exceptions.RetryError

        if response.status_code == wexc.HTTPBadRequest.code:
            self._handle_node_read_only_error(response)

        response.raise_for_status()

    def _handle_db_locked_error(self, response):
        """Treat 409 DB locked error as connection error."""
        text = jsonutils.loads(response.text)
        # DB locked error, VTS is overloaded. Treat this as a connection
        # error and retry later.
        confirm = re.search(
            'the configuration database is locked',
            text['errors']['error'][0]['error-message'])
        if confirm:
            raise requests.exceptions.ConnectionError

    def _handle_xrvr_out_of_sync_error(self, response, force_sync):
        try:
            text = jsonutils.loads(response.text)
            xrvr = re.search(
                'device (.+): out of sync',
                text['errors']['error'][0]['error-message']).group(1)
            if xrvr and not force_sync:
                LOG.info("Forcing XRVR sync")
                self._force_xrvr_sync(xrvr)
        except (IndexError, KeyError, AttributeError, ValueError,
                TypeError):
            # Probably not an out-of-sync error, just pass
            pass

    def _handle_node_read_only_error(self, response):
        """Treat 400 node read only error as connection error."""
        try:
            text = jsonutils.loads(response.text)
            confirm = re.search(
                'node is in readonly mode',
                text['errors']['error'][0]['error-message'])
            if confirm:
                raise requests.exceptions.ConnectionError
        except (IndexError, KeyError, AttributeError, ValueError,
                TypeError):
            # Not a node read only error
            pass

    def _force_xrvr_sync(self, xrvr):
        sync_url = self.url.split('/')[0] + '//' + self.url.split('/')[2]
        sync_url += constants.XRVR_SYNC_URI % xrvr

        self.sendjson('POST', sync_url, None, sync_force=True)
