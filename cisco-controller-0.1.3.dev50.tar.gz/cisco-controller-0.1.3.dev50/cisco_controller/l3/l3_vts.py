#  Copyright (c) 2016 Cisco Systems, Inc.
#  All Rights Reserved.
#
#  Licensed under the Apache License, Version 2.0 (the "License"); you may
#  not use this file except in compliance with the License. You may obtain
#  a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#  WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#  License for the specific language governing permissions and limitations
#  under the License.
#

from oslo_log import log as logging

from cisco_controller.common import client_vts
from cisco_controller.common import utils_vts
from cisco_controller.l3 import l3_base

LOG = logging.getLogger(__name__)

VTS = {'driver': client_vts.VirtualTopologySystemRestClient,
       'utils': utils_vts}


class CiscoControllerVTSL3RouterPlugin(
        l3_base.CiscoControllerBaseL3RouterPlugin):
    """Implementation of the VTS Cisco Controller L3 Router Service Plugin.

    """
    def get_controller_type(self):
        return VTS
