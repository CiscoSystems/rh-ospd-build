# Copyright (c) 2016 Cisco Systems Inc.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import copy
import requests
from unittest2.case import TestCase

from cisco_controller.common import client_vts
from cisco_controller.common import constants as cc_const
from cisco_controller.common import utils
from cisco_controller.common import utils_vts
from cisco_controller.journal.journal import Journal
from cisco_controller.ml2 import mech_vts
from cisco_controller.tests.unit.ml2 import base_driver_test_class

import mock
from oslo_serialization import jsonutils

from neutron.common import constants as n_const
from neutron.conf.plugins.ml2 import config
from neutron.db import provisioning_blocks
from neutron_lib.api.definitions import portbindings
from neutron_lib import constants
from neutron_lib import constants as nl_const
from neutron_lib.plugins.ml2 import api
from oslo_utils import uuidutils
from webob import exc as wexc

from cisco_controller.tests.unit.ml2 import test_cisco_controller

TEST_TENANT_NAME = 'tenant_name'
LONG_TENANT_NAME = 'very_long_tenant_name'

NETWORK_DICT = {
    'tenant_id': '123',
    'status': 'ACTIVE',
    'provider:network_type': 'test_type'}
NETWORK_DICT_MODIFIED = {cc_const.CC_NETWORK: {
    'tenant-id': '123',
    'tenant-name': TEST_TENANT_NAME,
    'status': utils_vts.VTS_OS_IDS_MODULE + 'ACTIVE',
    'provider-network-type': utils_vts.VTS_IDS_MODULE + 'test_type'}}
NETWORK_DICT_HIDDEN = {
    'id': '1234',
    'name': n_const.HA_NETWORK_NAME % '123',
    'tenant_id': '',
    'status': 'ACTIVE',
    'provider:network_type': 'test_type'}
NETWORK_DICT_HIDDEN_MODIFIED = {cc_const.CC_NETWORK: {
    'id': '1234',
    'name': n_const.HA_NETWORK_NAME % '123',
    'tenant-name': TEST_TENANT_NAME,
    'tenant-id': '123',
    'status': utils_vts.VTS_OS_IDS_MODULE + 'ACTIVE',
    'provider-network-type': utils_vts.VTS_IDS_MODULE + 'test_type'}}
SUBNET_DICT = {
    'tenant_id': '123'}
SUBNET_DICT_MODIFIED = {cc_const.CC_SUBNET: {
    'tenant-id': '123',
    'tenant-name': TEST_TENANT_NAME}}
TEST_LONG_TENANT_NAME_DICT = {
    'tenant_id': '1234'}
TEST_LONG_TENANT_NAME_DICT_MODIFIED = {cc_const.CC_SUBNET: {
    'tenant-id': '1234',
    'tenant-name': LONG_TENANT_NAME[-utils.MAX_TENANT_NAME_LEN:]}}
SUBNET_DICT_HIDDEN = {
    'id': '1234',
    'name': n_const.HA_SUBNET_NAME % '123',
    'tenant_id': ''}
SUBNET_DICT_HIDDEN_MODIFIED = {cc_const.CC_SUBNET: {
    'id': '1234',
    'name': n_const.HA_SUBNET_NAME % '123',
    'tenant-name': TEST_TENANT_NAME,
    'tenant-id': '123'}}
SUBNET_IPV6_DICT = {
    'tenant_id': '123',
    utils_vts.IPV6_RA_MODE: 'ipv6-test-ra',
    utils_vts.IPV6_ADDRESS_MODE: 'ipv6-test-address'}
SUBNET_IPV6_DICT_MODIFIED = {cc_const.CC_SUBNET: {
    'tenant-id': '123',
    'tenant-name': 'tenant_name',
    utils_vts.IPV6_RA_MODE: utils_vts.VTS_IDS_MODULE + 'ipv6-test-ra',
    utils_vts.IPV6_ADDRESS_MODE: (
        utils_vts.VTS_IDS_MODULE + 'ipv6-test-address')}}

mock_xrvr_failure_reply = """
{
  "errors": {
    "error": [
      {
        "error-message": "Network Element Driver: device xrvr2: out of sync",
        "error-tag": "malformed-message"
      }
    ]
  }
}
"""

mock_409_failure_reply = """
{
  "errors": {
    "error": [
      {
        "error-message": "the configuration database is locked",
        "error-tag": "in-use"
      }
    ]
  }
}
"""

mock_node_read_only_failure_reply = """
{
  "errors": {
    "error": [
      {
        "error-message": "node is in readonly mode",
        "error-tag": "malformed-message"
      }
    ]
  }
}
"""

_uuid = uuidutils.generate_uuid


class CiscoControllerVTSMechanismDriverTestCase(
    test_cisco_controller.CiscoControllerConfigBase):

    def _request_mock(self, *args, **kwargs):
        return self.request_response

    def setUp(self):
        super(CiscoControllerVTSMechanismDriverTestCase, self).setUp()
        config.cfg.CONF.set_override('vmm_id', '10', 'ml2_cc')
        self.request_mock = mock.patch.object(
            requests, 'request', side_effect=self._request_mock).start()
        mock.patch.object(Journal, '_prepare_maintenance_thread').start()
        self.mech = mech_vts.CiscoControllerVTSMechanismDriver()
        self.mech.initialize()

    def tearDown(self):
        super(CiscoControllerVTSMechanismDriverTestCase, self).tearDown()
        Journal._journal_thread = None

    def _get_vts_restclient(self):
        return client_vts.VirtualTopologySystemRestClient(
            url='mock_url', username='mock_user', password='mock_pass',
            timeout=360)

    def test_port_binding_allowed_for_vhostuser(self):
        """Check that set_binding is called and vif_details are correct."""
        context = mock.Mock()
        segment_id = _uuid()
        context.segments_to_bind = [{api.NETWORK_TYPE: constants.TYPE_VLAN,
                                     api.ID: segment_id}]
        port_id = _uuid()
        context.current = {'id': port_id}
        context.network.current = {'id': _uuid()}
        context.vif_type = portbindings.VIF_TYPE_VHOST_USER
        context.host_agents = lambda t: []
        self.mech.bind_port(context)
        context.set_binding.assert_called_with(
            segment_id, 'vhostuser',
            {portbindings.VHOST_USER_MODE:
             portbindings.VHOST_USER_MODE_SERVER,
             portbindings.VHOST_USER_OVS_PLUG: False,
             portbindings.VHOST_USER_SOCKET: '/tmp/' + port_id,
             portbindings.CAP_PORT_FILTER: True})

    def test_port_binding_allowed_for_unbound_ports(self):
        """Check that set_binding is called and vif_details are correct."""
        context = mock.Mock()
        segment_id = _uuid()
        context.segments_to_bind = [{api.NETWORK_TYPE: constants.TYPE_VLAN,
                                     api.ID: segment_id}]
        port_id = _uuid()
        context.current = {'id': port_id}
        context.network.current = {'id': _uuid()}
        context.vif_type = 'unbound'
        context.host_agents = lambda t: []
        self.mech.bind_port(context)
        context.set_binding.assert_called_with(
            segment_id, 'vhostuser',
            {portbindings.VHOST_USER_MODE:
             portbindings.VHOST_USER_MODE_SERVER,
             portbindings.VHOST_USER_OVS_PLUG: False,
             portbindings.VHOST_USER_SOCKET: '/tmp/' + port_id,
             portbindings.CAP_PORT_FILTER: True})

    def test_bind_port_ovs_vif_type(self):
        """Verify failure to bind when type is not VHOST_USER."""
        context = mock.Mock()
        segment_id = _uuid()
        context.segments_to_bind = [{api.NETWORK_TYPE: constants.TYPE_VLAN,
                                     api.ID: segment_id}]
        port_id = _uuid()
        context.current = {'id': port_id}
        context.network.current = {'id': _uuid()}
        context.host_agents = lambda t: [{'binary': 'neutron-vts-agent',
                                          'alive': True}]
        context.vif_type = 'unbound'
        self.mech.bind_port(context)
        context.set_binding.assert_called_with(
            segment_id, 'ovs', {portbindings.CAP_PORT_FILTER: True,
                                portbindings.OVS_HYBRID_PLUG: True})

    def test_bind_port_normal_vnic_type(self):
        """Verify failure to bind when type is not VHOST_USER."""
        context = mock.Mock()
        segment_id = _uuid()
        context.segments_to_bind = [{api.NETWORK_TYPE: constants.TYPE_VLAN,
                                     api.ID: segment_id}]
        port_id = _uuid()
        context.current = {'id': port_id,
                           portbindings.VNIC_TYPE: u'normal'}
        context.network.current = {'id': _uuid()}
        context.host_agents = lambda t: [{'binary': 'neutron-vts-agent',
                                          'alive': True}]
        context.vif_type = 'unbound'
        self.mech.bind_port(context)
        context.set_binding.assert_called()

    def ovs_test_bind_port_normal_vnic_type(self):
        """Verify failure to bind when type is not VHOST_USER."""
        context = mock.Mock()
        segment_id = _uuid()
        context.segments_to_bind = [{api.NETWORK_TYPE: constants.TYPE_VLAN,
                                     api.ID: segment_id}]
        port_id = _uuid()
        context.current = {'id': port_id,
                           portbindings.VNIC_TYPE: u'normal'}
        context.network.current = {'id': _uuid()}
        context.host_agents = lambda t: \
            [{'binary': 'neutron-openvswitch-agent', 'alive': True}]
        context.vif_type = 'unbound'
        self.mech.bind_port(context)
        context.set_binding.assert_called()

    def test_bind_port_non_normal_vnic_type(self):
        """Verify failure to bind when type is not VHOST_USER."""
        context = mock.Mock()
        segment_id = _uuid()
        context.segments_to_bind = [{api.NETWORK_TYPE: constants.TYPE_VLAN,
                                     api.ID: segment_id}]
        port_id = _uuid()
        context.current = {'id': port_id,
                           portbindings.VNIC_TYPE: portbindings.VNIC_DIRECT}
        context.network.current = {'id': _uuid()}
        context.host_agents = lambda t: [{'binary': 'neutron-vts-agent',
                                          'alive': True}]
        context.vif_type = 'unbound'
        self.mech.bind_port(context)
        context.set_binding.assert_not_called()

    def ovs_test_bind_port_non_normal_vnic_type(self):
        """Verify failure to bind when type is not VHOST_USER."""
        context = mock.Mock()
        segment_id = _uuid()
        context.segments_to_bind = [{api.NETWORK_TYPE: constants.TYPE_VLAN,
                                     api.ID: segment_id}]
        port_id = _uuid()
        context.current = {'id': port_id,
                           portbindings.VNIC_TYPE: portbindings.VNIC_DIRECT}
        context.network.current = {'id': _uuid()}
        context.host_agents = lambda t: \
            [{'binary': 'neutron-openvswitch-agent', 'alive': True}]
        context.vif_type = 'unbound'
        self.mech.bind_port(context)
        context.set_binding.assert_not_called()

    def test_get_vhostuser_vif_details(self):
        """Verify VIF details for VHOSTUSER - using ID."""
        self.context.current = {'id': 'test-id'}
        actual = self.mech._get_vif_details(portbindings.VIF_TYPE_VHOST_USER,
                                            self.context)
        expected = {
            portbindings.CAP_PORT_FILTER: True,
            portbindings.VHOST_USER_MODE: portbindings.VHOST_USER_MODE_SERVER,
            portbindings.VHOST_USER_OVS_PLUG: False,
            portbindings.VHOST_USER_SOCKET: '/tmp/test-id'}
        self.assertEqual(expected, actual)

    def _get_mock_request_reply(self, status_code, reply):
        return_obj = lambda: 0
        return_obj.status_code = status_code
        return_obj.raise_for_status = lambda: None
        return_obj.text = reply

        return return_obj

    def _test_force_xrvr_sync(self, return_code, reply=None):
        """Test if the client forces an xrvr sync on a HTTP error."""
        client = self._get_vts_restclient()
        client.force_sync_xrvr = True
        self.request_response = self._get_mock_request_reply(
            return_code, reply)
        pmock = mock.patch.object(client_vts.VirtualTopologySystemRestClient,
                                  '_force_xrvr_sync',
                                  return_value=None).start()
        client.sendjson('GET', 'fake_url', None)

        return pmock

    def test_force_xrvr_sync_on_error(self):
        """Test if the client forces an xrvr sync on a HTTP error."""
        pmock = self._test_force_xrvr_sync(wexc.HTTPNotFound.code,
                                           mock_xrvr_failure_reply)
        pmock.assert_called_with('xrvr2')

    def test_no_force_xrvr_sync_on_success(self):
        """Test if the client does not force an xrvr sync on a HTTP success."""
        pmock = self._test_force_xrvr_sync(wexc.HTTPOk.code)
        self.assertFalse(pmock.called)

    def test_409_raises_connection_error(self):
        """Check if a 409 response raises a connection error."""
        client = self._get_vts_restclient()
        self.request_response = self._get_mock_request_reply(
            wexc.HTTPConflict.code, mock_409_failure_reply)
        self.assertRaises(requests.exceptions.ConnectionError,
                          client.sendjson, 'GET', 'fake_url', None)

    def test_delete_404_raises_retry_error(self):
        """Check if a 404 response raises a RetryError."""
        client = self._get_vts_restclient()
        self.request_response = self._get_mock_request_reply(
            wexc.HTTPNotFound.code, None)
        self.assertRaises(requests.exceptions.RetryError,
                          client.sendjson, 'DELETE', 'fake_url', None)

    def test_non_delete_404_does_not_raise_retry_error(self):
        """Check no exception raised for a non delete operation 404."""
        client = self._get_vts_restclient()
        self.request_response = self._get_mock_request_reply(
            wexc.HTTPNotFound.code, mock_409_failure_reply)
        self.assertIsNone(client.sendjson('PUT', 'fake_url', None))

    def test_node_read_only_error_raises_connection_error(self):
        """Check if a node read only error raises a connection error."""
        client = self._get_vts_restclient()
        self.request_response = self._get_mock_request_reply(
            wexc.HTTPBadRequest.code, mock_node_read_only_failure_reply)
        self.assertRaises(requests.exceptions.ConnectionError,
                          client.sendjson, 'GET', 'fake_url', None)

    def test_400_non_read_only_error_no_exception(self):
        """Check if non node read only error raises no connection error."""
        client = self._get_vts_restclient()
        self.request_response = self._get_mock_request_reply(
            wexc.HTTPBadRequest.code, None)
        self.assertIsNone(client.sendjson('GET', 'fake_url', None))


class TestVtsModifiers(TestCase):

    def setUp(self):
        super(TestVtsModifiers, self).setUp()
        mock.patch.object(utils,
                          '_get_tenant_name',
                          return_value=TEST_TENANT_NAME).start()

    def test_port_modifier(self):
        expected = {cc_const.CC_PORT: {
            'tenant-id': '123',
            'tenant-name': 'tenant_name',
            'status': 'cisco-vts-openstack-identities:ACTIVE',
            'description': 'ABC',
            'binding-vif-type': 'cisco-vts-openstack-identities:vhostuser',
            'binding-vif-details': {
                'port-filter': True,
                'vhostuser-mode': 'cisco-vts-openstack-identities:server',
                'vhostuser-socket': '/tmp/fa163e8d99b6'},
        }}
        port = {
            'tenant_id': '123',
            'status': 'ACTIVE',
            'description': 'ABC',
            'binding:vif_type': 'vhostuser',
            'binding:vif_details': {
                'port_filter': True,
                'vhostuser_mode': 'server',
                'vhostuser_socket': '/tmp/fa163e8d99b6',
            }
        }
        modified_port = utils_vts.PortModify.modify_create_attributes(port)
        self.assertEqual(expected, modified_port)

    def test_hidden_port_modifier(self):
        expected = {cc_const.CC_PORT: {
            'id': '1234',
            'name': n_const.HA_PORT_NAME % '123',
            'tenant-id': '123',
            'tenant-name': 'tenant_name',
            'status': 'cisco-vts-openstack-identities:ACTIVE',
            'description': 'ABC',
            'binding-vif-type': 'cisco-vts-openstack-identities:vhostuser',
            'binding-vif-details': {
                'port-filter': True,
                'vhostuser-mode': 'cisco-vts-openstack-identities:server',
                'vhostuser-socket': '/tmp/fa163e8d99b6'},
        }}
        port = {
            'id': '1234',
            'name': n_const.HA_PORT_NAME % '123',
            'tenant_id': '',
            'status': 'ACTIVE',
            'description': 'ABC',
            'binding:vif_type': 'vhostuser',
            'binding:vif_details': {
                'port_filter': True,
                'vhostuser_mode': 'server',
                'vhostuser_socket': '/tmp/fa163e8d99b6',
            }
        }
        modified_port = utils_vts.PortModify.modify_create_attributes(port)
        self.assertEqual(expected, modified_port)

    def test_port_modifier_when_vif_details_but_no_port_filter(self):
        """Should not see this case, but checking it is handled OK."""
        expected = {cc_const.CC_PORT: {
            'tenant-id': '123',
            'tenant-name': 'tenant_name',
            'status': 'cisco-vts-openstack-identities:DOWN',
            'description': 'ABC',
            'binding-vif-type': 'cisco-vts-openstack-identities:vhostuser',
            'binding-vif-details': {
                'port-filter': False,
                'vhostuser-mode': 'cisco-vts-openstack-identities:server',
                'vhostuser-socket': '/tmp/fa163e8d99b6'},
        }}
        port = {
            'tenant_id': '123',
            'status': 'DOWN',
            'description': 'ABC',
            'binding:vif_type': 'vhostuser',
            'binding:vif_details': {
                'vhostuser_mode': 'server',
                'vhostuser_socket': '/tmp/fa163e8d99b6',
            }
        }
        modified_port = utils_vts.PortModify.modify_create_attributes(port)
        self.assertEqual(expected, modified_port)

    def test_network_create_modifier(self):
        network_dict = copy.deepcopy(NETWORK_DICT)
        modified_network = (
            utils_vts.NetworkModify.modify_create_attributes(network_dict))
        self.assertEqual(NETWORK_DICT_MODIFIED, modified_network)

    def test_hidden_network_create_modifier(self):
        network_dict = copy.deepcopy(NETWORK_DICT_HIDDEN)
        modified_network = (
            utils_vts.NetworkModify.modify_create_attributes(network_dict))
        self.assertEqual(NETWORK_DICT_HIDDEN_MODIFIED, modified_network)

    def test_network_update_modifier(self):
        network_dict = copy.deepcopy(NETWORK_DICT)
        modified_network = (
            utils_vts.NetworkModify.modify_update_attributes(network_dict))
        self.assertEqual(NETWORK_DICT_MODIFIED, modified_network)

    def test_hidden_subnet_create_modifier(self):
        subnet_dict = copy.deepcopy(SUBNET_DICT_HIDDEN)
        modified_subnet = (
            utils_vts.SubnetModify.modify_create_attributes(subnet_dict))
        self.assertEqual(SUBNET_DICT_HIDDEN_MODIFIED, modified_subnet)

    def test_subnet_create_modifier(self):
        subnet_dict = copy.deepcopy(SUBNET_DICT)
        modified_subnet = (
            utils_vts.SubnetModify.modify_create_attributes(subnet_dict))
        self.assertEqual(SUBNET_DICT_MODIFIED, modified_subnet)

    def test_subnet_update_modifier(self):
        subnet_dict = copy.deepcopy(SUBNET_DICT)
        modified_subnet = (
            utils_vts.SubnetModify.modify_update_attributes(subnet_dict))
        self.assertEqual(SUBNET_DICT_MODIFIED, modified_subnet)

    def test_subnet_create_ipv6_modifier(self):
        subnet_dict = copy.deepcopy(SUBNET_IPV6_DICT)
        modified_subnet = (
            utils_vts.SubnetModify.modify_create_attributes(subnet_dict))
        self.assertEqual(SUBNET_IPV6_DICT_MODIFIED, modified_subnet)

    def test_subnet_update_ipv6_modifier(self):
        subnet_dict = copy.deepcopy(SUBNET_IPV6_DICT)
        modified_subnet = (
            utils_vts.SubnetModify.modify_update_attributes(subnet_dict))
        self.assertEqual(SUBNET_IPV6_DICT_MODIFIED, modified_subnet)

    def test_long_tenant_name(self):
        mock.patch.object(utils,
                          '_get_tenant_name',
                          return_value=LONG_TENANT_NAME).start()
        subnet_dict = copy.deepcopy(TEST_LONG_TENANT_NAME_DICT)
        modified_subnet = (
            utils_vts.SubnetModify.modify_create_attributes(subnet_dict))
        self.assertEqual(TEST_LONG_TENANT_NAME_DICT_MODIFIED, modified_subnet)


class VtsMechanismDriverTestCase(
    base_driver_test_class.CiscoControllerMechanismDriverTestCase):

    def setUp(self):
        self.mech_driver = mech_vts.CiscoControllerVTSMechanismDriver
        self.controller_info = mech_vts.VTS
        self.uses_verify = True
        self.utils = utils_vts
        self.headers = {'Content-Type': 'application/vnd.yang.data+json'}
        super(VtsMechanismDriverTestCase, self).setUp()

    def test_activation_after_create(self):
        """Check if a port's status is set to ACTIVE after an update."""
        pmock = mock.Mock()
        add = mock.patch.object(provisioning_blocks,
                                'add_provisioning_component',
                                return_value=pmock).start()
        complete = mock.patch.object(provisioning_blocks,
                                     'provisioning_complete',
                                     return_value=pmock).start()
        self._test_thread_processing(cc_const.CC_CREATE, cc_const.CC_PORT)
        self.assertEqual(add.call_count, 1)
        self.assertEqual(complete.call_count, 1)

    def test_port_update_no_change(self):
        add_event = mock.patch.object(Journal,
                                      'add_event').start()
        context = self._get_mock_operation_context('port')
        context.current["description"] = "test"
        context.original = context.current.copy()
        method = getattr(self.mech, 'update_port_postcommit')
        method(context)
        self._wait_processing()
        self.assertEqual(self.request_mock.call_count, 0)
        self.assertEqual(add_event.call_count, 0)

    def test_port_db_row_not_created(self):
        """Verify that db rows are not created for certain device_owners."""
        for device_owner in [nl_const.DEVICE_OWNER_ROUTER_INTF,
                             nl_const.DEVICE_OWNER_ROUTER_GW]:
            current = {'device_owner': device_owner}
            context = mock.Mock(current=current)
            for operation in [cc_const.CC_CREATE, cc_const.CC_UPDATE,
                              cc_const.CC_DELETE]:
                method = getattr(self.mech, '%s_port_precommit' %
                                 operation)
                method(context)
                self._wait_processing()
                self.assertEqual(self.request_mock.call_count, 0)

    def test_obj_excludes(self):
        username = None
        password = None
        timeout = 120
        root_url = 'http://'
        urlpath = 'vmm/10'
        url = root_url + '/' + urlpath + '/'
        client = client_vts.VirtualTopologySystemRestClient(root_url,
                                                            username,
                                                            password,
                                                            timeout=timeout)
        obj = {'a': {}, 'b': {'project-id': 'a'}, 'c': [{'project-id': 'a'}]}
        output = {'a': {}, 'b': {}, 'c': [{}]}
        response = mock.Mock(status_code=200)

        mock.patch.object(jsonutils, 'dumps',
                          side_effect=lambda obj, indent: obj).start()
        with mock.patch('requests.request',
                        return_value=response) as mock_method:
            client.sendjson(None, '', obj)

        mock_method.assert_called_with(
            None, auth=(username, password),
            data=output,
            headers={'Content-Type': 'application/vnd.yang.data+json'},
            timeout=timeout, url=url, verify=False)

    def _getUrl(self, base_url, path):
        return base_url + 'vmm/10/' + path
