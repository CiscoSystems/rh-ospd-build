#
# Copyright (C) 2016 Red Hat, Inc.
#
#  Licensed under the Apache License, Version 2.0 (the "License"); you may
#  not use this file except in compliance with the License. You may obtain
#  a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#  Unless required by applicable law or agreed to in writing, software
#  distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#  WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#  License for the specific language governing permissions and limitations
#  under the License.
#
import platform
import traceback

from neutron.db import api as neutron_db_api
from oslo_config import cfg
from oslo_log import log as logging
from oslo_service import loopingcall

from cisco_controller.db import db
from cisco_controller.db import models

LOG = logging.getLogger(__name__)


class MaintenanceThread(object):
    def __init__(self):
        self.timer = None
        self.maintenance_interval = cfg.CONF.ml2_cc.maintenance_interval
        self.node_name = platform.node()
        self.maintenance_ops = []

    def start(self, db_engine):
        # Create a maintenance row if one doesn't exist
        LOG.debug("Starting Maintenance thread from:\n%s",
                  traceback.format_stack())
        session = neutron_db_api.get_writer_session()
        db.init_db(db_engine, models.MaintenanceTable)
        row = db.create_maintenance_row(session)
        # in case there's crash while maintenance was running on this host
        # reset the maintenance lock
        if row.node_name == self.node_name:
            db.unlock_maintenance(session)
            db.update_maintenance_operation(session, operation=None)

        self.timer = loopingcall.FixedIntervalLoopingCall(self.execute_ops)
        self.timer.start(self.maintenance_interval, stop_on_exception=False)

    def stop(self):
        LOG.info("Stopping maintenance thread interval looping")
        if self.timer is None:
            return
        self.timer.stop()

    def _execute_op(self, operation, session):
        op_details = operation.__name__
        if operation.__doc__:
            op_details += " (%s)" % operation.func_doc

        try:
            LOG.info("Starting maintenance operation %s.", op_details)
            db.update_maintenance_operation(session, operation=operation)
            operation(session=session)
            LOG.info("Finished maintenance operation %s.", op_details)
        except Exception:
            LOG.exception("Failed during maintenance operation %s.",
                          op_details)

    def execute_ops(self):
        LOG.debug("Starting journal maintenance run.")
        session = neutron_db_api.get_writer_session()
        if not db.lock_maintenance(session, self.node_name):
            LOG.debug("Maintenance already running, aborting.")
            return

        try:
            for operation in self.maintenance_ops:
                self._execute_op(operation, session)
        finally:
            db.update_maintenance_operation(session, operation=None)
            db.unlock_maintenance(session)
            LOG.debug("Finished journal maintenance run.")

    def register_operation(self, f):
        """Register a function to be run by the maintenance thread.

        :param f: Function to call when the thread runs. The function will
        receive a DB session to use for DB operations.
        """
        self.maintenance_ops.append(f)
