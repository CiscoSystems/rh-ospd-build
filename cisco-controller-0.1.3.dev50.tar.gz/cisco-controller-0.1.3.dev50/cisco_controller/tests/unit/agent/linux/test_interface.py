# Copyright 2016 Cisco Systems, Inc
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import mock

from neutron.tests.unit.agent.linux import test_interface
from oslo_config import cfg

from cisco_controller.drivers.agent.linux import interface


class FakePortForNamespace(test_interface.FakePort):
    id = '095eefc3-06d7-4aa0-9207-09e1a79ae58d'


class TestNamespaceDriver(test_interface.TestBase):

    def setUp(self):
        super(TestNamespaceDriver, self).setUp()
        self.sleep = mock.patch('eventlet.sleep').start()
        self.network_id = '01234567-1234-1234-99'
        self.port_id = '095eefc3-06d7-4aa0-9207-09e1a79ae58d'
        self.device_name = 'ns-0'
        self.mac_address = 'aa:bb:cc:dd:ee:ff'
        self.nsd = interface.NamespaceDriver(self.conf)
        self.ns_dev = mock.Mock()
        self.ip().device = mock.Mock(return_value=self.ns_dev)

    def test_get_device_name(self):
        device_name = self.nsd.get_device_name(FakePortForNamespace())
        self.assertEqual('t-095eefc306d7', device_name)

    def test_plug_with_namespace_and_mtu(self):
        expected = [
            mock.call(),
            mock.call().device(self.device_name),
            mock.call().ensure_namespace('foo'),
            mock.call().ensure_namespace().add_device_to_namespace(
                self.ns_dev)
        ]

        self.nsd.plug(self.network_id,
                      self.port_id,
                      self.device_name,
                      self.mac_address,
                      namespace='foo', mtu=1500)

        self.ip.assert_has_calls(expected)
        self.ns_dev.assert_has_calls(
            [mock.call.link.set_address(self.mac_address),
             mock.call.link.set_mtu(1500),
             mock.call.link.set_up()])

    def test_ignore_deprecated_mtu_config(self):
        """Expect to ignore, if not available any more."""
        self.conf.unregister_opt(cfg.IntOpt('network_device_mtu'))
        self.nsd._configure_mtu(self.ns_dev, mtu=1300)
        self.ns_dev.assert_has_calls([mock.call.link.set_mtu(1300)])

    def test_unplug_with_namespace(self):
        self.nsd.unplug(device_name='tap-0', namespace='foo')
        self.ip.assert_has_calls(
            [mock.call().garbage_collect_namespace('foo')])

    def test_timeout_waiting_for_device_existence(self):
        self.device_exists.side_effect = (
            [False] * interface.MAX_TIME_FOR_DEVICE_EXISTENCE
        )
        result = interface.NamespaceDriver._device_is_created_in_time(
            "bogus-dev")
        self.assertFalse(result)

    def test_device_exists_before_timeout(self):
        self.device_exists.side_effect = [False, False, True]
        result = interface.NamespaceDriver._device_is_created_in_time(
            "tap-dev")
        self.assertTrue(result)
        self.assertEqual(2, self.sleep.call_count)
        self.assertEqual(3, self.device_exists.call_count)
