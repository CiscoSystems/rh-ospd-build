ODL Drivers Architecture
========================

This document covers architectural concepts of the ODL drivers. Although
'driver' is an ML2 term, it's used widely in ODL to refer to any
implementation of APIs. Any mention of ML2 in this document is solely for
reference purposes.

V1 Driver Overview
------------------

The first driver version was a naive implementation which synchronously
mirrored all calls to the ODL controller. For example, a create network request
would first get written to the DB by Neutron's ML2 plugin, and then the ODL
driver would send the request to POST the network to the ODL controller.

Although this implementation is simple, it has a few problems:

* ODL is not really synchronous, so if the REST call succeeds it doesn't mean
  the action really happened on ODL.
* The "synchronous" call can be a bottleneck under load.
* Upon failure the V1 driver would try to "full sync" the entire Neutron DB
  over on the next call, so the next call could take a very long time.
* It doesn't really handle race conditions:

  - For example, create subnet and then create port could be sent in parallel
    by the driver in an HA Neutron environment, causing the port creation to
    fail.
  - Full-sync could possibly recreate deleted resources if the deletion happens
    in parallel.

.. _v2_design:

V2 Driver Design
----------------

The V2 driver set upon to tackle problems encountered in the V1 driver while
maintaining feature parity.
The major design concept of the V2 driver is *journaling* - instead of passing
the calls directly to the VTS controller, they get registered
in the journal table which keeps a sort of queue of the various operations that
occurred on Neutron and should be mirrored to the controller.

The journal is processed by a journaling thread which is triggered when
the first operation is added to the queue. This journaling thread will exist
till it process all the events currently in the DB.

If we take the example of create network again, after it gets stored in the
Neutron DB by the ML2 plugin, the VTS driver stores a "journal entry"
representing that operation, when the journaling thread process the event,
the info is transmitted to the controller.

Journal Entry Lifecycle
-----------------------

The entry exists in the journaling DB while it is not synced to the controller.
The events are indexed (the index is just a number) according to their arrival
time and are processed in the same order. The second event will be processed
only after sending the first event (the operation itself could succeed or
fail). Indexing is done using DB auto-increment feature. The index is reset
when adding an entry to an empty DB (when all the events had been processed).

In case of a failure the thread determines if this is an expected failure (e.g.
network connectivity issue) or an unexpected failure. For unexpected failures
a counter is raised, so that a given entry won't be retried more than a given
amount of times. Expected failures don't change the counter. If the counter
exceeds the configured amount of retries, the entry is removed (assuming
a failure). Otherwise, the entry is retried after a small amount of time.

High Availability design guidelines
-----------------------------------
At every given moment there is a single journaling thread across the HA
cluster. The event will arrive at a single controller, and when adding it to
the DB, if this is the first entry, then it will trigger the pulling thread.

Maintenance thread will make sure that if the thread that should have processed
the events had crashed these events will be processed anyway. It will check
whether the first entry in the DB has ‘last_retried’ old enough to assume
that the controller who should have processed had crashed.

Cisco-controller architecture
=============================

Cisco-controller is based on networking-odl sources. It has the same design
goal as networking-odl, while communicating with different backend -- VTS
instead of ODL.

It had started as a fork to 'networking-odl' and is not kept in-sync.
It has an abstraction layer for the backend, so in theory it support ODL and
VTS, but ODL is not used, so not actually verified.

Feedback from VTS
-----------------
Because of its async nature, V2 implementation has a drawback that if
the backend refuses some operation it cannot fail (as in V1), since
communication happens at a later stage.

The journaling thread makes sure that after a successful sync an object status
could be updated or some other operation performed (see
'utils.post_row_operation_method').
If the sync had failed, the operation could be reverted (see
'failure_handler.handle').

Additional features
-------------------
- Throttling
  To make sure it is not run too frequently and to prepare the code to support
  batch operations the journaling thread has the logic to run at maximum once
  in a while (once in a sec. in its current configuration)

- Trunk Port Feature
  J-Driver supports trunk port feature with Openstack Newton. JDriver registers
  for trunk and subport CRUD operations. On receiving the event callback, it
  adds the event to the Journal table. The journaling thread retreives the
  event, processes and sends it to VTC. If trunk create/delete fails, then
  the operation is reverted. If subport set/unset fails then by using the
  subport list in the original_trunk, current_trunk it is determined whether it
  is set/ unset then approriate neutron API is called to revert the operation.
  In case if set fails, the subports are unset by calling
  trunk_remove_subports. In case if unset fails, the subports are set back by
  calling trunk_add_subports.

  Tox test framework covers the following for trunk port feature
  - trunk CRUD success,
  - subport set/unset success,
  - trunk CRUD failure
  - subport set/unset failure
  - Test the payload generated by J-Driver which is sent to VTC
  CRUD, subport set/unset

- Security Groups
  With OpenStack Newton onward, JDriver now supports Security Groups and
  Security Group Rules CRUD operations. The ml2 plugin supports this feature by
  registering to the Security Groups plugin that registers for all the CRUD
  operations. OpenStack supports Create, Update, Delete operations for Security
  Groups, and only Create and Delete operations for Security Group Rules.

  In addition to the user-defined security groups, a default security group
  is created per tenant which is used by VM ports by default. The current
  implementation has utils for getting the default security group along with
  the rules, given a database session object. The default security group create
  event gets implicitly triggered when the first network gets created, post
  creation of a new tenant. For brown field deployments -- with existing
  tenants and networks, one way to send this information to the appropriate
  controller is by performing an 'update' operation on the 'description'
  field of default security group.

  All these CRUD operations are put into the Journaling database, which is
  then processed by the journaling thread before sending it to the controller.

  Unfortunately, Security Group Rule deletion operation doesn't provide the
  parent object's identifier - corresponding Security Group, the current
  rule is associated to. So the plugin queries neutron to fetch this
  information, before putting this delete event in the journaling database.
  Note: All 'create' and 'update' operations are post-commits, while the
  'delete' operations are pre-commits with respect to the neutron database.

  If a Security Group/ Security Group creation fails, it is cleaned up on
  OpenStack. This behavior still needs some discussion. Update failures
  propagating from the controller will lead to inconsistency between
  OpenStack and the appropriate controller in use (this behavior is identical
  to the other OpenStack constructs -- network, subnet, etc), and will not
  lead to cleaning up of the corresponding object on OpenStack.

 Test cases coverage for this feature include:
   - TBD(abradhak)

