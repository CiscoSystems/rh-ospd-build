# Copyright (c) 2013-2016 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
from oslo_config import cfg
from oslo_log import log as logging

from neutron.agent import securitygroups_rpc
from neutron.db import provisioning_blocks
from neutron_lib.api.definitions import portbindings
from neutron_lib.callbacks import resources
from neutron_lib import constants as n_const
from neutron_lib.plugins.ml2 import api

from cisco_controller.common import client_vts
from cisco_controller.common import constants as cc_const
from cisco_controller.common import utils
from cisco_controller.common import utils_vts
from cisco_controller.ml2 import mech_base
from cisco_controller.sg import driver as sg_driver
from cisco_controller.trunk import driver as trunk_driver

VTS = {'driver': client_vts.VirtualTopologySystemRestClient,
       'utils': utils_vts}

ALLOWED_AGENTS = ['neutron-vts-agent', 'neutron-openvswitch-agent']

UPDATE_FIELDS = ['binding:vif_type',
                 'binding:vif_details',
                 'binding:vnic_type',
                 'fixed_ips',
                 'description',
                 'status',
                 'security_groups']

LOG = logging.getLogger(__name__)

IPTABLES_FW_DRIVER_FULL = \
    "neutron.agent.linux.iptables_firewall.OVSHybridIptablesFirewallDriver"
IPTABLES_HYBRID = "iptables_hybrid"


class CannotBind(Exception):
    pass


class CiscoControllerVTSMechanismDriver(
        mech_base.CiscoControllerBaseMechanismDriver):
    """Cisco Controller VTS mechanism driver.

    This code is the backend implementation for the Virtual Topology System
    ML2 MechanismDriver for OpenStack Neutron.
    """
    agent_type = n_const.AGENT_TYPE_OVS

    def initialize(self):
        super(CiscoControllerVTSMechanismDriver, self).initialize()
        trunk_driver.register(self.journal)
        sg_driver.register(self.journal)
        sg_enabled = securitygroups_rpc.is_firewall_enabled()
        firewall_dirver = cfg.CONF.SECURITYGROUP.firewall_driver
        hybrid_plug_required = sg_enabled and (not firewall_dirver or
                                               firewall_dirver in
                                               (IPTABLES_FW_DRIVER_FULL,
                                                IPTABLES_HYBRID))
        self.ovs_vif_details = {portbindings.CAP_PORT_FILTER: True,
                                portbindings.OVS_HYBRID_PLUG:
                                hybrid_plug_required}
        LOG.debug('Initializing vif details. SG Enabled: %(sg_enabled)s, '
                  'HybridPlug: %(hybrid_plug)s',
                  {'sg_enabled': str(sg_enabled), 'hybrid_plug': str(
                   hybrid_plug_required)})

    SRIOV_VNIC_TYPES = {portbindings.VNIC_DIRECT,
                        portbindings.VNIC_MACVTAP,
                        portbindings.VNIC_DIRECT_PHYSICAL}
    SUPPORTED_VNIC_TYPES = {portbindings.VNIC_NORMAL}
    KNOWN_VNIC_TYPES = SUPPORTED_VNIC_TYPES | SRIOV_VNIC_TYPES

    def get_controller_type(self):
        return VTS

    def should_send_event(self, object_type, operation, data):
        if data['tenant_id'] == '':
            LOG.info('Skipping %(object_type)s %(id)s %(operation)s due '
                     'to empty tenant_id (hidden object)',
                     {'object_type': object_type,
                      'id': data['id'],
                      'operation': operation})
            return False
        if object_type == cc_const.CC_PORT:
            if not self._is_supported_deviceowner(data):
                LOG.info('Skipping port %(id)s %(operation)s due to '
                         'device owner',
                         {'id': data['id'], 'operation': operation})
                return False
            if not self.is_vnic_type_known(data):
                LOG.info('Skipping port %(id)s %(operation)s due to '
                         'vnic type',
                         {'id': data['id'], 'operation': operation})
                return False
            return True
        return True

    @staticmethod
    def _is_supported_deviceowner(port):
        device_owner = port.get('device_owner')
        return device_owner not in {None,
                                    n_const.DEVICE_OWNER_ROUTER_INTF,
                                    n_const.DEVICE_OWNER_ROUTER_GW,
                                    n_const.DEVICE_OWNER_HA_REPLICATED_INT}

    def port_has_updates(self, original, current):
        if 'migrating_to' in current['binding:profile']:
            LOG.info('Skipping port %s update due to migration',
                     current['id'])
            LOG.debug('UPDATE FIELDS (migration):\nOriginal: %s\nCurrent: %s',
                      repr(original), repr(current))
            return False
        for field in UPDATE_FIELDS:
            if current[field] != original[field]:
                LOG.debug('UPDATE FIELDS (changed: %s):\nOriginal: %s\n'
                          'Current: %s',
                          repr(field), repr(original), repr(current))
                return True

        LOG.info('Skipping port %s update due to no changes',
                 current['id'])
        LOG.debug('UPDATE FIELDS (checked: %s):\nOriginal: %s\n'
                  'Current: %s',
                  repr(UPDATE_FIELDS), repr(original), repr(current))
        return False

    # we are interested only in types that we handle
    def is_vnic_type_known(self, port):
        vnic_type = port.get(portbindings.VNIC_TYPE, portbindings.VNIC_NORMAL)
        return vnic_type in self.KNOWN_VNIC_TYPES

    def create_port_postcommit(self, context):
        provision = self._insert_provisioning_block(context)
        super(CiscoControllerVTSMechanismDriver,
              self).create_port_postcommit(context, provision=provision)

    def update_port_postcommit(self, context):
        if not self.port_has_updates(context.original, context.current):
            return

        provision = self._insert_provisioning_block(context)
        super(CiscoControllerVTSMechanismDriver,
              self).update_port_postcommit(context, provision=provision)

    def _insert_provisioning_block(self, context):
        # we insert a status barrier to prevent the port from transitioning
        # to active until VTC reports back that the wiring is done
        port = context.current
        if context.original and \
           context.original['status'] == n_const.PORT_STATUS_ACTIVE:
            LOG.info("Status was ACTIVE for port %s, skip "
                     "provisioning block", port['id'])
            return False
        if not context.host or port['status'] == n_const.PORT_STATUS_ACTIVE:
            # no point in putting in a block if the status is already ACTIVE
            return False
        provisioning_blocks.add_provisioning_component(
            context._plugin_context, port['id'], resources.PORT,
            utils.VTC_PROVISIONING_ENTITY)
        return True

    def delete_port_precommit(self, context):
        super(CiscoControllerVTSMechanismDriver,
              self).delete_port_precommit(context)

    def get_vif_type(self, context):
        vnic_type = context.current.get(portbindings.VNIC_TYPE,
                                        portbindings.VNIC_NORMAL)
        if vnic_type not in self.SUPPORTED_VNIC_TYPES:
            LOG.info("Unsupported vnic_type: %s", vnic_type)
            raise CannotBind()

        # if there's VTS agent, this means we have either VM vtf or
        # physical TOR
        for agent in context.host_agents(self.agent_type):
            # XXX: current VTS install agent even for vhostuser, so make
            # sure admin state is up, before considering a valid agent
            if not agent['alive']:
                continue
            if agent['binary'] in ALLOWED_AGENTS:
                vif_type = portbindings.VIF_TYPE_OVS
                break
        else:
            vif_type = portbindings.VIF_TYPE_VHOST_USER

        LOG.info("Bound using vif_type: %s", vif_type)
        return vif_type

    def _get_vif_details(self, vif_type, context):
        if vif_type == portbindings.VIF_TYPE_VHOST_USER:
            # VHOST VIF type: use '/tmp/UUID' for the socket path.
            return {
                portbindings.VHOST_USER_MODE:
                    portbindings.VHOST_USER_MODE_SERVER,
                portbindings.VHOST_USER_OVS_PLUG: False,
                portbindings.VHOST_USER_SOCKET:
                    '/tmp/%s' % context.current['id'],
                portbindings.CAP_PORT_FILTER: True}
        else:
            return self.ovs_vif_details

    def bind_port(self, port_context):
        LOG.info("Attempting to bind port %(port)s on "
                 "network %(network)s",
                 {'port': port_context.current['id'],
                  'network': port_context.network.current['id']})
        for segment in port_context.segments_to_bind:
            if self.check_segment_for_agent(segment):
                break
            LOG.info("Refusing to bind port for segment ID %(id)s, "
                     "segment %(seg)s, phys net %(physnet)s, and "
                     "network type %(nettype)s",
                     {'id': segment[api.ID],
                      'seg': segment[api.SEGMENTATION_ID],
                      'physnet': segment[api.PHYSICAL_NETWORK],
                      'nettype': segment[api.NETWORK_TYPE]})
        else:
            LOG.warning('No suitable segment found')
            segment = None  # to silence a Flake8 warning
            return

        try:
            vif_type = self.get_vif_type(port_context)
            port_context.set_binding(segment[api.ID], vif_type,
                                     self._get_vif_details(vif_type,
                                                           port_context))
            LOG.info("Bound using segment: %s", segment)
        except CannotBind:
            LOG.info("Cannot bind using segment: %s", segment)
