# Copyright (c) 2014 Red Hat Inc.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from cisco_controller._i18n import _
from oslo_config import cfg

cc_opts = [
    cfg.StrOpt('url',
               help=_("HTTP URL of CiscoController REST interface.")),
    cfg.StrOpt('username',
               help=_("HTTP username for authentication")),
    cfg.StrOpt('password', secret=True,
               help=_("HTTP password for authentication")),
    cfg.IntOpt('timeout', default=10,
               help=_("HTTP timeout in seconds.")),
    cfg.IntOpt('session_timeout', default=30,
               help=_("Tomcat session timeout in minutes.")),
    cfg.StrOpt('vmm_id', default=None,
               help=_("vmm id for openstack")),
    cfg.IntOpt('sync_timeout', default=10,
               help=_("(V2 driver) Sync thread timeout in seconds.")),
    cfg.IntOpt('retry_count', default=0,
               help=_("(V2 driver) Number of times to retry a row "
                      "before failing.")),
    cfg.IntOpt('maintenance_interval', default=300,
               help=_("Journal maintenance operations interval "
                      "in seconds.")),
    cfg.IntOpt('max_batch', default=9,
               help=_("Maximum number of events that will be processed "
                      "in a batch")),
    cfg.IntOpt('completed_rows_retention', default=600,
               help=_("Time to keep completed rows in seconds."
                      "Completed rows retention will be checked every "
                      "maintenance_interval by the cleanup thread."
                      "To disable completed rows deletion "
                      "value should be -1")),
    cfg.IntOpt('processing_timeout', default='300',
               help=_("(V2 driver) Time in seconds to wait before a "
                      "processing row is marked back to pending.")),
    cfg.BoolOpt('force_sync_xrvr', default=False,
                help=_("Force a VTC-XRVR sync when the driver detects an "
                       "out of sync state")),
    cfg.BoolOpt('delete_failed_instance_port', default=False,
                help=_("Delete the Neutron port for an Instance if it is "
                       "in ERROR state")),
    cfg.IntOpt('max_concurrent_vts_events', default='19',
               help=_("Maximum number of parallel threads that will "
                      "send events to VTS")),
]

cfg.CONF.register_opts(cc_opts, "ml2_cc")
