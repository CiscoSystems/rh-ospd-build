# Copyright (c) 2016 Cisco Systems Inc.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import datetime
from neutronclient.common import exceptions as nc_exceptions
from neutronclient.v2_0 import client as neutronclient_v2
import requests

from cisco_controller.common import constants as cc_const
from cisco_controller.common import utils
from cisco_controller.db import db
from cisco_controller.db import models
from cisco_controller.journal.journal import Journal
from cisco_controller.tests.unit.ml2 import test_cisco_controller

import mock

from keystoneauth1.identity import generic
from keystoneauth1 import session
from neutron.conf.plugins.ml2 import config
from neutron.db import api as neutron_db_api
from neutron_lib import constants
from neutron_lib.plugins.ml2 import api
from oslo_utils import uuidutils

SECURITY_GROUP = '2f9244b4-9bee-4e81-bc4a-3f3c2045b3d7'
TEST_TENANT_NAME = 'tenant_name'

_uuid = uuidutils.generate_uuid


class CiscoControllerMechanismDriverTestCase(
    test_cisco_controller.CiscoControllerConfigBase):

    def _request_mock(self, *args, **kwargs):
        return self.request_response

    def _create_session(self):
        auth = generic.Password('')
        return session.Session(auth=auth)

    def setUp(self):
        super(CiscoControllerMechanismDriverTestCase, self).setUp()
        self.db_session = neutron_db_api.get_writer_session()
        self._session = self._create_session()
        mock.patch.object(utils,
                          '_get_tenant_name',
                          return_value=TEST_TENANT_NAME).start()
        mock.patch.object(utils, '_get_session',
                          return_value=self._session).start()
        self.request_response = self._get_mock_request_response(200)
        self.request_mock = mock.patch.object(
            requests, 'request', side_effect=self._request_mock).start()
        self.addCleanup(self._db_cleanup)
        mock.patch.object(Journal, '_prepare_maintenance_thread').start()
        self.mech = self.mech_driver()
        self.mech.initialize()
        self.thread = self.mech.journal._journal_thread

    def tearDown(self):
        super(CiscoControllerMechanismDriverTestCase, self).tearDown()
        Journal._journal_thread = None

    @staticmethod
    def _get_mock_network_operation_context():
        current = {'status': 'ACTIVE',
                   'subnets': [],
                   'name': 'net1',
                   'provider:physical_network': None,
                   'admin_state_up': True,
                   'tenant_id': 'test-tenant',
                   'tenant_name': TEST_TENANT_NAME,
                   'provider:network_type': 'local',
                   'router:external': False,
                   'shared': False,
                   'id': 'd897e21a-dfd6-4331-a5dd-7524fa421c3e',
                   'provider:segmentation_id': None}
        context = mock.Mock(current=current, original=dict())
        context._plugin_context.session = neutron_db_api.get_writer_session()
        return context

    @staticmethod
    def _get_mock_subnet_operation_context():
        current = {'ipv6_ra_mode': None,
                   'allocation_pools': [{'start': '10.0.0.2',
                                         'end': '10.0.1.254'}],
                   'host_routes': [],
                   'ipv6_address_mode': None,
                   'cidr': '10.0.0.0/23',
                   'id': '72c56c48-e9b8-4dcf-b3a7-0813bb3bd839',
                   'name': '',
                   'enable_dhcp': True,
                   'network_id': 'd897e21a-dfd6-4331-a5dd-7524fa421c3e',
                   'tenant_id': 'test-tenant',
                   'tenant_name': TEST_TENANT_NAME,
                   'dns_nameservers': [],
                   'gateway_ip': '10.0.0.1',
                   'ip_version': 4,
                   'shared': False}
        context = mock.Mock(current=current, original=dict())
        context._plugin_context.session = neutron_db_api.get_writer_session()
        return context

    @staticmethod
    def _get_mock_port_operation_context():
        current = {'status': 'DOWN',
                   'binding:host_id': '',
                   'allowed_address_pairs': [],
                   'device_owner': 'fake_owner',
                   'binding:profile': {},
                   'fixed_ips': [{
                       'subnet_id': '72c56c48-e9b8-4dcf-b3a7-0813bb3bd839'}],
                   'id': '83d56c48-e9b8-4dcf-b3a7-0813bb3bd940',
                   'security_groups': [SECURITY_GROUP],
                   'device_id': 'fake_device',
                   'name': '',
                   'admin_state_up': True,
                   'network_id': 'd897e21a-dfd6-4331-a5dd-7524fa421c3e',
                   'tenant_id': 'test-tenant',
                   'tenant_name': TEST_TENANT_NAME,
                   'binding:vif_details': {'port_filter': True},
                   'binding:vnic_type': 'normal',
                   'binding:vif_type': 'unbound',
                   'mac_address': '12:34:56:78:21:b6'}
        original = current.copy()
        original['binding:vif_details'] = ''
        context = mock.Mock(current=current, original=original)
        context._plugin.get_security_group = mock.Mock(
            return_value=SECURITY_GROUP)
        context._plugin.get_port = mock.Mock(return_value=current)
        context._plugin_context.session = neutron_db_api.get_writer_session()
        context._network_context = mock.Mock(
            _network=CiscoControllerMechanismDriverTestCase.
            _get_mock_network_operation_context().current)
        return context

    @classmethod
    def _get_mock_operation_context(cls, object_type):
        getter = getattr(cls, '_get_mock_%s_operation_context' % object_type)
        return getter()

    _status_code_msgs = {
        200: '',
        201: '',
        204: '',
        400: '400 Client Error: Bad Request',
        401: '401 Client Error: Unauthorized',
        403: '403 Client Error: Forbidden',
        404: '404 Client Error: Not Found',
        409: '409 Client Error: Conflict',
        501: '501 Server Error: Not Implemented',
        503: '503 Server Error: Service Unavailable',
    }

    def _db_cleanup(self):
        rows = db.get_all_db_rows(self.db_session)
        for row in rows:
            db.delete_row(self.db_session, exact_id=row.id)

    @classmethod
    def _get_mock_request_response(cls, status_code, reply=None):
        response = mock.Mock(status_code=status_code)
        response.raise_for_status = mock.Mock() if status_code < 400 else (
            mock.Mock(side_effect=requests.exceptions.HTTPError(
                cls._status_code_msgs[status_code])))
        if reply is not None:
            response.text = reply
        return response

    def _get_mock_request_reply(self, status_code, reply):
        return_obj = lambda: 0

        return return_obj

    def _wait_processing(self):
        self.thread.wait_processing()

    def _test_operation(self, context, expected_calls,
                        strict_check, *args, **kwargs):
        if expected_calls and strict_check:
            self.request_mock.assert_called_with(
                headers=self.headers,
                auth=(config.cfg.CONF.ml2_cc.username,
                      config.cfg.CONF.ml2_cc.password),
                timeout=config.cfg.CONF.ml2_cc.timeout, *args, **kwargs)
        self.assertEqual(expected_calls, self.request_mock.call_count)
        self.request_mock.reset_mock()

    def _call_operation_object(self, operation, object_type, status_code):
        context = self._get_mock_operation_context(object_type)
        method = getattr(self.mech, '%s_%s_postcommit' % (operation,
                                                          object_type))
        self.request_response = self._get_mock_request_response(status_code)
        method(context)
        self._wait_processing()

    def _getUrl(self, base_url, path):
        return base_url + path

    def _test_thread_processing(self, operation, object_type,
                                expected_calls=1, strict_check=True,
                                status_code=None):
        status_codes = {cc_const.CC_CREATE: requests.codes.created,
                        cc_const.CC_UPDATE: requests.codes.ok,
                        cc_const.CC_DELETE: requests.codes.no_content}

        http_request = self.utils.HTTP_METHOD_MAP[operation]
        urlpath_def = self.utils.URL_PATH_MAP[operation]
        status_code = status_code or status_codes[operation]

        self._call_operation_object(operation, object_type, status_code)

        context = self._get_mock_operation_context(object_type)

        url_object_type = object_type.replace('_', '-')
        test_row = models.JournalTable(
            object_type=None, object_uuid=context.current['id'],
            operation=None, data=None, created_at=None)
        url = self._getUrl('%s/' % config.cfg.CONF.ml2_cc.url,
                           urlpath_def(url_object_type, test_row))

        if operation in [cc_const.CC_CREATE, cc_const.CC_UPDATE]:
            kwargs = {
                'url': url,
                'data': test_cisco_controller.DataMatcher(
                    operation, object_type, context,
                    self.utils.MODIFY_MAP[object_type])}
        else:
            kwargs = {'url': url, 'data': None}

        if self.uses_verify:
            kwargs.update({'verify': False})

        self._test_operation(context, expected_calls,
                             strict_check, http_request, **kwargs)

    def _test_object_type(self, object_type):
        success_count = mock.patch.object(utils,
                                          'post_row_operation_methods').start()
        # Add and process create request.
        self._test_thread_processing(cc_const.CC_CREATE, object_type)
        self.assertEqual(1, success_count.call_count)

        # Add and process update request. Adds to database.
        self._test_thread_processing(cc_const.CC_UPDATE, object_type)
        self.assertEqual(2, success_count.call_count)

        # Add and process update request. Adds to database.
        self._test_thread_processing(cc_const.CC_DELETE, object_type)
        self.assertEqual(3, success_count.call_count)

    def _test_object_operation_failure(self, operation, base_object_types,
                                       object_type, func_mock):
        # Create base objects (creates db row in pending state).
        objs_count = 1
        for t in base_object_types:
            self._call_operation_object(operation, t, 200)
            objs_count += 1

        # Create object_type database row and process. This results in all
        # the base_object_types and object_type rows being processed.
        self.thread._row_retry_count = 1
        self._test_thread_processing(operation, object_type,
                                     expected_calls=objs_count,
                                     strict_check=False, status_code=400)

        # Verify that all objects are now marked as failed,
        # and operations reverted
        self.assertEqual(func_mock.call_count, 1)
        return func_mock.call_count

    def _test_failed_instance_port_delete(self, status, expected_delete):
        # Test processing an update port triggers the condition or not
        config.cfg.CONF.set_override('delete_failed_instance_port',
                                     True, 'ml2_cc')
        self.thread._post_methods = {}
        with mock.patch.object(utils, '_get_instance_state',
                               return_value=status) as umock:
            with mock.patch.object(utils, '_get_neutron_plugin') as pmock:
                self._test_thread_processing(cc_const.CC_UPDATE,
                                             cc_const.CC_PORT,
                                             expected_calls=1)
                umock.assert_called_with('fake_device')
                if expected_delete:
                    self.assertTrue(pmock.called)
                else:
                    self.assertFalse(pmock.called)

    def test_network(self):
        self._test_object_type(cc_const.CC_NETWORK)

    def test_subnet(self):
        self._test_object_type(cc_const.CC_SUBNET)

    def test_network_create_failure(self):
        self._test_object_operation_failure(
            cc_const.CC_CREATE,
            [], cc_const.CC_NETWORK,
            mock.patch.object(neutronclient_v2.Client,
                              'delete_network').start())

    def test_subnet_create_failure(self):
        self._test_object_operation_failure(
            cc_const.CC_CREATE,
            [cc_const.CC_NETWORK], cc_const.CC_SUBNET,
            mock.patch.object(neutronclient_v2.Client,
                              'delete_subnet').start())

    def test_port_create_failure(self):
        self._test_object_operation_failure(
            cc_const.CC_CREATE,
            [cc_const.CC_NETWORK, cc_const.CC_SUBNET], cc_const.CC_PORT,
            mock.patch.object(neutronclient_v2.Client,
                              'delete_port').start())

    def _delete_port_raise_exception(*args, **kwargs):
        raise nc_exceptions.PortNotFoundClient

    def test_port_create_failure_w_exception(self):
        self._test_object_operation_failure(
            cc_const.CC_CREATE,
            [cc_const.CC_NETWORK, cc_const.CC_SUBNET], cc_const.CC_PORT,
            mock.patch.object(neutronclient_v2.Client, 'delete_port',
                              side_effect=self._delete_port_raise_exception
                              ).start())

    def test_network_update_failure(self):
        self._test_object_operation_failure(
            cc_const.CC_UPDATE,
            [], cc_const.CC_NETWORK,
            mock.patch.object(neutronclient_v2.Client,
                              'update_network').start())

    def test_subnet_update_failure(self):
        self._test_object_operation_failure(
            cc_const.CC_UPDATE,
            [cc_const.CC_NETWORK], cc_const.CC_SUBNET,
            mock.patch.object(neutronclient_v2.Client,
                              'update_subnet').start())

    def test_port_update_failure(self):
        self._test_object_operation_failure(
            cc_const.CC_UPDATE,
            [cc_const.CC_NETWORK, cc_const.CC_SUBNET], cc_const.CC_PORT,
            mock.patch.object(neutronclient_v2.Client,
                              'update_port').start())

    def test_port(self):
        self._test_object_type(cc_const.CC_PORT)

    def test_failed_instance_port_deleted(self):
        self._test_failed_instance_port_delete('ERROR', expected_delete=True)

    def test_successful_instance_port_not_deleted(self):
        self._test_failed_instance_port_delete('SUCCESS',
                                               expected_delete=False)

    def test_check_segment(self):
        """Validate the check_segment_for_agent call."""
        segment = {'api.NETWORK_TYPE': ""}
        segment[api.NETWORK_TYPE] = constants.TYPE_LOCAL
        self.assertTrue(self.mech.check_segment_for_agent(segment))
        segment[api.NETWORK_TYPE] = constants.TYPE_FLAT
        self.assertTrue(self.mech.check_segment_for_agent(segment))
        segment[api.NETWORK_TYPE] = constants.TYPE_VLAN
        self.assertTrue(self.mech.check_segment_for_agent(segment))
        segment[api.NETWORK_TYPE] = constants.TYPE_GRE
        self.assertTrue(self.mech.check_segment_for_agent(segment))
        segment[api.NETWORK_TYPE] = constants.TYPE_VXLAN
        self.assertTrue(self.mech.check_segment_for_agent(segment))
        # Validate a network type not currently supported
        segment[api.NETWORK_TYPE] = 'mpls'
        self.assertFalse(self.mech.check_segment_for_agent(segment))

    def _decrease_row_created_time(self, row):
        row.created_at -= datetime.timedelta(hours=1)
        self.db_session.merge(row)
        self.db_session.flush()
