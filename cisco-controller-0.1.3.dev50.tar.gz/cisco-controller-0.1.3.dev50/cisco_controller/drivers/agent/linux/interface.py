# Copyright 2016 Cisco Systems, Inc.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import eventlet

from neutron.agent.linux import interface
from neutron.agent.linux import ip_lib
from oslo_config import cfg
from oslo_log import log as logging

LOG = logging.getLogger(__name__)
MAX_TIME_FOR_DEVICE_EXISTENCE = 30


class NamespaceDriver(interface.LinuxInterfaceDriver):
    """Device independent network namespace interface driver."""

    def get_device_name(self, port):
        # Forcing name to use Upper 8 bits of Port-UUID
        name = "t-%s" % port.id.replace('-', '')
        LOG.debug("Generated device name %s", name)
        return name[:self.DEV_NAME_LEN]

    @classmethod
    def _device_is_created_in_time(cls, device_name):
        """See if device is created, within time limit."""
        attempt = 0
        while attempt < MAX_TIME_FOR_DEVICE_EXISTENCE:
            if ip_lib.device_exists(device_name):
                return True
            attempt += 1
            eventlet.sleep(1)
        LOG.error("Device %(dev)s was not created in %(time)d seconds",
                  {'dev': device_name, 'time': MAX_TIME_FOR_DEVICE_EXISTENCE})
        return False

    def plug(self, network_id, port_id, device_name, mac_address,
             bridge=None, namespace=None, prefix=None, mtu=None):
        # Overriding this, as we don't expect that the device will exist yet,
        # but if it does, we still want to add the device into the namespace.
        self.plug_new(network_id, port_id, device_name, mac_address,
                      bridge, namespace, prefix, mtu)

    def _configure_mtu(self, ns_dev, mtu=None):
        # Need to set MTU, after added to namespace. See review
        # https://review.openstack.org/327651
        try:
            # Note: network_device_mtu will be deprecated in future
            mtu_override = self.conf.network_device_mtu
        except cfg.NoSuchOptError:
            LOG.warning("Config setting for MTU deprecated - any "
                        "override will be ignored.")
            mtu_override = None
        if mtu_override:
            mtu = mtu_override
            LOG.debug("Overriding MTU to %d", mtu)
        if mtu:
            ns_dev.link.set_mtu(mtu)
        else:
            LOG.debug("No MTU provided - skipping setting value")

    def plug_new(self, network_id, port_id, device_name, mac_address,
                 bridge=None, namespace=None, prefix=None, mtu=None):
        """Adds device (e.g. tap port) into namespace.

        Sets MAC and MTU, but does not create device, like other
        device drivers (e.g. no 'ip add link'). It is expected that
        this is handled outside of this device driver, based on the
        device type, and could take some time (so we wait for the
        creation).
        """

        ip = ip_lib.IPWrapper()
        ns_dev = ip.device(device_name)

        LOG.debug("Plugging interface net:%s port:%s dev:%s mac:%s ns:%s",
                  network_id, port_id, device_name, mac_address, namespace)

        # Wait for device creation
        if not self._device_is_created_in_time(device_name):
            return

        ns_dev.link.set_address(mac_address)

        if namespace:
            LOG.debug("Adding device %s to namespace %s",
                      ns_dev.name, namespace)
            namespace_obj = ip.ensure_namespace(namespace)
            namespace_obj.add_device_to_namespace(ns_dev)

        self._configure_mtu(ns_dev, mtu)

        ns_dev.link.set_up()

    def unplug(self, device_name, bridge=None, namespace=None, prefix=None):
        # Since we do not add device, there is no delete needed.
        LOG.debug("Unplugged interface: '%s'", device_name)
        ip_lib.IPWrapper(namespace).garbage_collect_namespace()
