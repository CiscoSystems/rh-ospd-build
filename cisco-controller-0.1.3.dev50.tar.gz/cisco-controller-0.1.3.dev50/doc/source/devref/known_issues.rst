Known issues
============

Journaling thread run causes constant DB Lock
---------------------------------------------
There's a problem with the current implementation of the main loop of the
journaling thread, namely:
When there's more than one instance of the journaling thread, there's constant
"competition" which instance will take the first element from the db, see
'db.get_oldest_pending_db_row_with_lock' definition and use.

Keep the code in sync with networking-odl upstream
--------------------------------------------------
Preferrably we want to keep cisco-controller code base in-sync with
networking-odl upstream. Such sync could simplify:

- upstream bugfixes
- upstream new features

