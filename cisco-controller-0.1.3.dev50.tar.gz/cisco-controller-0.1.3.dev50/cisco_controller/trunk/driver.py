# Copyright 2017 cisco Systems inc
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.

from cisco_controller.common import constants as cc_const

from oslo_config import cfg
from oslo_log import log as logging

from neutron.db import api as db_api
from neutron.services.trunk import constants as trunk_consts
from neutron.services.trunk.drivers import base
from neutron_lib.api.definitions import portbindings
from neutron_lib.callbacks import events
from neutron_lib.callbacks import registry
from neutron_lib import constants as n_consts

LOG = logging.getLogger(__name__)

NAME = 'cisco_vts'

SUPPORTED_INTERFACES = (
    portbindings.VIF_TYPE_OVS,
    portbindings.VIF_TYPE_VHOST_USER,
)

SUPPORTED_SEGMENTATION_TYPES = (
    trunk_consts.VLAN,
)

DRIVER = None

RESOURCE_TO_EVENT = {events.AFTER_CREATE: cc_const.CC_CREATE,
                     events.AFTER_UPDATE: cc_const.CC_UPDATE,
                     events.AFTER_DELETE: cc_const.CC_DELETE}


class VTSDriver(base.DriverBase):

    def __init__(self, journal):
        super(VTSDriver, self).__init__(
            NAME,
            SUPPORTED_INTERFACES,
            SUPPORTED_SEGMENTATION_TYPES,
            n_consts.AGENT_TYPE_OVS)

        self.journal = journal

        registry.subscribe(self.send_data,
                           trunk_consts.TRUNK,
                           events.AFTER_CREATE)
        registry.subscribe(self.send_data,
                           trunk_consts.TRUNK,
                           events.AFTER_UPDATE)
        registry.subscribe(self.send_data,
                           trunk_consts.TRUNK,
                           events.AFTER_DELETE)
        registry.subscribe(self.send_data,
                           trunk_consts.SUBPORTS,
                           events.AFTER_CREATE)
        registry.subscribe(self.send_data,
                           trunk_consts.SUBPORTS,
                           events.AFTER_DELETE)

    def payload_to_dict(self, p):
        return {'trunk_id': p.trunk_id,
                'current_trunk': p.current_trunk,
                'original_trunk': p.original_trunk,
                'subports': p.subports}

    @property
    def is_loaded(self):
        try:
            return NAME in cfg.CONF.ml2.mechanism_drivers
        except cfg.NoSuchOptError:
            return False

    @classmethod
    def create(cls, journal):
        return VTSDriver(journal)

    def send_data(self, resource, event, trigger, payload=None):
        LOG.debug('VTS trunk driver event: {resource} {event} {payload}'
                  ''.format(resource=resource, event=event,
                            payload=self.payload_to_dict(payload)))
        session = db_api.get_writer_session()
        eventToSend = RESOURCE_TO_EVENT[event]

        # subport add/delete is sent as a trunk update with
        # resource as trunk
        if resource == trunk_consts.SUBPORTS:
            eventToSend = cc_const.CC_UPDATE
        self.journal.add_event(session, trunk_consts.TRUNK,
                               payload.trunk_id, eventToSend,
                               self.payload_to_dict(payload))


def register(journal):
    """Register the driver."""
    global DRIVER
    DRIVER = VTSDriver.create(journal)
    # To set the bridge_name in a parent port's vif_details.
    LOG.debug('VTS trunk driver registered')
