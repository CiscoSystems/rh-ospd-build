# Copyright (c) 2015 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import six

from eventlet.semaphore import Semaphore
import sqlalchemy as sa
from sqlalchemy import or_, and_, not_

from cisco_controller.common import constants as cc_const
from cisco_controller.db import models

from neutron.db import api as db_api

from oslo_db import api as oslo_db_api
from oslo_log import log as logging

LOG = logging.getLogger(__name__)


class decoratorSubtransactionWithRetry(object):
    # the assumption is that all decorators are using the same session,
    # so make sure it is not re-used while using it
    sem = Semaphore()

    def __init__(self, subtransaction=True):
        self.subtransaction = subtransaction

    def __call__(self, f):
        @db_api.retry_db_errors
        @six.wraps(f)
        def wrapped(session, *args, **kwargs):
            with decoratorSubtransactionWithRetry.sem:
                if not self.subtransaction:
                    return f(session, *args, **kwargs)
                with session.begin(subtransactions=True):
                    return f(session, *args, **kwargs)
        return wrapped


@decoratorSubtransactionWithRetry(subtransaction=False)
def get_all_db_rows(session):
    return session.query(models.JournalTable).all()


@decoratorSubtransactionWithRetry(subtransaction=False)
def get_ordered_rows(session, limit=None, obj_type=None, not_obj_type=None,
                     wo_port_ids=None, port_id=None):
    q = session.query(models.JournalTable).order_by(
        sa.asc(models.JournalTable.id))
    if obj_type is not None:
        q = q.filter(models.JournalTable.object_type == obj_type)
    if not_obj_type is not None:
        q = q.filter(models.JournalTable.object_type != not_obj_type)
    if port_id is not None:
        q = q.filter(models.JournalTable.object_type == cc_const.CC_PORT,
                     models.JournalTable.object_uuid == port_id)
    if wo_port_ids:
        q = q.filter(
            or_(and_(models.JournalTable.object_type == cc_const.CC_PORT,
                     not_(models.JournalTable.object_uuid.in_(wo_port_ids))),
                models.JournalTable.object_type != cc_const.CC_PORT))
    if limit is None:
        return q
    return q.limit(limit)


@decoratorSubtransactionWithRetry()
def db_row_update(session, row):
    session.merge(row)


def inc_db_row_retry(session, row):
    row.retry_count += 1
    db_row_update(session, row)
    return row.retry_count


@decoratorSubtransactionWithRetry()
def delete_row(session, exact_id=-1, ids_below=-1):
    if exact_id != -1:
        session.query(models.JournalTable).filter(
            models.JournalTable.id == exact_id).delete()
    else:
        session.query(models.JournalTable).filter(
            models.JournalTable.id <= ids_below).delete()


def reset_autoinc(session):
    con = session.connection()
    if con.dialect.name == 'sqlite':
        # sqlite is auto resetting id when the table is empty
        return None
    rp = con.execute('ALTER TABLE {tablename} AUTO_INCREMENT = {initial}'
                     ''.format(
                         tablename=models.JournalTable.__tablename__,
                         initial=models.INITIAL_AUTOINC_NUM))
    return rp


@decoratorSubtransactionWithRetry()
def update_last_retried(session, row):
    row.save(session)


def _create_row(object_type, object_uuid,
                operation, vtc_data, data, old_data, provision=False):
    row = models.JournalTable(object_type=object_type,
                              object_uuid=object_uuid,
                              operation=operation,
                              vtc_data=vtc_data,
                              data=data, old_data=old_data,
                              provision=provision,
                              created_at=sa.func.now())
    return row


@decoratorSubtransactionWithRetry()
def create_row_w_reset(session, object_type, object_uuid,
                       operation, vtc_data, data, old_data, provision=False):
    reset_autoinc(session)
    row = _create_row(object_type, object_uuid, operation,
                      vtc_data, data, old_data, provision=provision)
    session.add(row)
    return row


@decoratorSubtransactionWithRetry()
def create_row(session, object_type, object_uuid,
               operation, vtc_data, data, old_data, provision=False):
    row = _create_row(object_type, object_uuid, operation,
                      vtc_data, data, old_data, provision=provision)
    session.add(row)
    return row


def create_maintenance_row(session):
    """Create the first maintenance row."""
    with session.begin():
        try:
            # check if a maintenance row exists first
            row = session.query(models.MaintenanceTable).one()
        except sa.orm.exc.NoResultFound:
            # Create a maintenance row
            row = models.MaintenanceTable(state=cc_const.PENDING)
            session.add(row)
            session.flush()
        return row


@oslo_db_api.wrap_db_retry(max_retries=db_api.MAX_RETRIES,
                           retry_on_deadlock=True)
def _update_maintenance_state(session, node_name, expected_state, state):
    with session.begin():
        try:
            row = session.query(models.MaintenanceTable).filter_by(
                state=expected_state).with_for_update().one()
        except sa.orm.exc.NoResultFound:
            return False

        row.state = state
        row.node_name = node_name
        return True


def lock_maintenance(session, node_name):
    return _update_maintenance_state(session, node_name,
                                     cc_const.PENDING, cc_const.PROCESSING)


def unlock_maintenance(session):
    return _update_maintenance_state(session, None,
                                     cc_const.PROCESSING, cc_const.PENDING)


@oslo_db_api.wrap_db_retry(max_retries=db_api.MAX_RETRIES,
                           retry_on_deadlock=True)
def update_maintenance_operation(session, operation=None):
    """Update the current maintenance operation details.

    The function assumes the lock is held, so it mustn't be run outside of a
    locked context.
    """
    op_text = None
    if operation:
        op_text = operation.__name__

    with session.begin():
        try:
            row = session.query(models.MaintenanceTable).one()
            row.processing_operation = op_text
        except sa.orm.exc.NoResultFound:
            pass


def _validate_schema(engine, model):
    model_table = model.__table__
    try:
        db_table = sa.Table(model.__tablename__, sa.MetaData(),
                            autoload=True, autoload_with=engine)
    except sa.exc.NoSuchTableError:
        return None

    # check that DB and Model has the same rows
    db_columns = set(db_table.columns.keys())
    model_columns = set(model_table.columns.keys())
    db_missing = model_columns - db_columns
    model_missing = db_columns - model_columns
    if db_missing:
        return 'Missing rows from db: %s' % list(db_missing)
    if model_missing:
        return 'Missing rows from model: %s' % list(model_missing)

    # check that the type of every row is the same, a special check
    # exists for 'bool' which in the DB is represented as 'int'
    for column in model_table.columns:
        model_type = column.type.python_type
        db_type = db_table.columns[column.name].type.python_type
        if model_type == db_type:
            continue
        if model_type == bool and db_type == int:
            continue
        return ('Column %s has different type - db: %s, model: %s' %
                (column.name, repr(db_type), repr(model_type)))
    return None


def _create_table(engine, model):
    table = model.__table__
    if table.exists(bind=engine):
        return
    table.create(bind=engine)


def _drop_table(engine, model):
    table = model.__table__
    table.drop(bind=engine)


def init_db(engine, model):
    schema_error = _validate_schema(engine, model)
    if schema_error is not None:
        LOG.warning('Schema of %(model)s had changed: %(change)s. '
                    'Dropping the table',
                    {'model': model, 'change': schema_error})
        _drop_table(engine, model)

    _create_table(engine, model)
