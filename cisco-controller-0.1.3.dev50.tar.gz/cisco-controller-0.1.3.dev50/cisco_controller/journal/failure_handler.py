# Copyright (c) 2017 cisco Systems Inc.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from collections import namedtuple
from neutronclient.common import exceptions as nc_exceptions
from six import iteritems

from cisco_controller.common import constants as cc_const
from cisco_controller.common import utils
from oslo_log import log as logging

LOG = logging.getLogger(__name__)

FuncMap = namedtuple('FuncMap', ['func_name', 'params'])


DELETE_MAP = {
    cc_const.CC_SG: FuncMap('delete_security_group',
                            {'security_group': 'id'}),
    cc_const.CC_SG_RULE: FuncMap('delete_security_group_rule',
                                 {'security_group_rule': 'id'}),
    cc_const.CC_NETWORK: FuncMap('delete_network', {'network': 'id'}),
    cc_const.CC_SUBNET: FuncMap('delete_subnet', {'subnet': 'id'}),
    cc_const.CC_PORT: FuncMap('delete_port', {'port': 'id'}),
    cc_const.CC_ROUTER: FuncMap('delete_router', {'router': 'id'}),
    cc_const.CC_ROUTER_INTF: FuncMap('remove_interface_router',
                                     {'router': 'id',
                                      'body': 'subnet_id'}),
    cc_const.CC_FLOATINGIP: FuncMap('delete_floatingip',
                                    {'floatingip': 'id'}),
    cc_const.CC_TRUNK: FuncMap('delete_trunk',
                               {'trunk': 'trunk_id'}),
}

UPDATE_MAP = {
    cc_const.CC_NETWORK: FuncMap('update_network', {'network': 'id'}),
    cc_const.CC_SUBNET: FuncMap('update_subnet', {'subnet': 'id'}),
    cc_const.CC_PORT: FuncMap('update_port', {'port': 'id'}),
    cc_const.CC_ROUTER: FuncMap('update_router', {'router': 'id'}),
    cc_const.CC_FLOATINGIP: FuncMap('update_floatingip',
                                    {'floatingip': 'id'}),
}


def trunk_update_failure_handler(nc, row):
    original_trunk = row.data['original_trunk']
    current_trunk = row.data['current_trunk']

    original_subports = []
    current_subports = []
    LOG.debug("failure handler trunk")

    for s in original_trunk['sub_ports']:
        original_subports.append(s['port_id'])
    orig_subport_set = set(original_subports)

    for s in current_trunk['sub_ports']:
        current_subports.append(s['port_id'])
    curr_subport_set = set(current_subports)

    added_subports = curr_subport_set - orig_subport_set
    removed_subports = orig_subport_set - curr_subport_set

    if removed_subports:
        LOG.debug("subport unset operation")
        ret = nc.trunk_add_subports(row.data['trunk_id'],
                                    {'sub_ports': row.data['subports']})
        LOG.debug('UPDATE after failure for trunk %(trunk)s \
                  returned %(ret)s',
                  {'trunk': row.data['trunk_id'], 'ret': repr(ret)})
    if added_subports:
        LOG.debug("subport set operation")
        ret = nc.trunk_remove_subports(row.data['trunk_id'],
                                       {'sub_ports': row.data['subports']})
        LOG.debug('UPDATE after failure for trunk %(trunk)s \
                  returned %(ret)s',
                  {'trunk': row.data['trunk_id'], 'ret': repr(ret)})


def handle(row):
    def finish():
        utils.provision_complete(row)
        return None

    if row.operation == cc_const.CC_DELETE:
        return finish()

    nc = utils.get_neutron_client()
    try:
        if row.operation in {cc_const.CC_CREATE, cc_const.CC_ADD}:
            details = DELETE_MAP[row.object_type]
            func = getattr(nc, details.func_name)
            params = {k: row.data[v] for k, v in iteritems(details.params)}
            if row.object_type == cc_const.CC_ROUTER_INTF:
                # for router interface the body is in a different format
                params['body'] = {'%s_id' % 'subnet': params['body']}
            func(**params)
            return finish()
        # Update port had failed
        if row.object_type == cc_const.CC_PORT:
            port = row.data['id']
            ret = nc.update_port(port, {'port': {'binding:host_id': ''}})
            LOG.debug('UPDATE after failure for port %(port)s returned '
                      '%(ret)s', {'port': port, 'ret': repr(ret)})
            return finish()
    except nc_exceptions.PortNotFoundClient:
        LOG.warning('Port %(port)s was already removed',
                    {'port': row.data['id']})

    if row.object_type == cc_const.CC_TRUNK:
        trunk_update_failure_handler(nc, row)
        return finish()

    # revert the update operation
    try:
        details = UPDATE_MAP[row.object_type]
    except KeyError:
        # TODO(pginchev) implement all update failures
        # SG/SG_RULE is missing (or not needed)
        return finish()
    func = getattr(nc, details.func_name)
    params = {k: row.data[v] for k, v in iteritems(details.params)}
    params['body'] = {row.object_type: row.old_data}
    LOG.debug('revert update after failure for %(type)s: %(params)s',
              {'type': row.object_type, 'params': params})
    func(**params)
    return finish()
