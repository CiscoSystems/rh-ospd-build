# Copyright (c) 2016 Cisco Systems, Inc.
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import requests

from cisco_controller.common import client_vts
from cisco_controller.common import constants as cc_const
from cisco_controller.common import utils
from cisco_controller.common import utils_vts
from cisco_controller.db import db
from cisco_controller.journal.journal import Journal
from cisco_controller.l3 import l3_vts
from cisco_controller.ml2 import mech_vts
from cisco_controller.sg import driver as sgdriver


import mock
from oslo_serialization import jsonutils

from neutron.conf.plugins.ml2 import config
from neutron.db import api as neutron_db_api
from neutron.tests.unit.db import test_db_base_plugin_v2
from neutron_lib.api.definitions import external_net
from neutron_lib import context
from neutron_lib.plugins import constants as plugin_constants
from neutron_lib.plugins import directory

EMPTY_DEP = []
FLOATINGIP_ID = 'floatingip_uuid'
NETWORK_ID = 'network_uuid'
ROUTER_ID = 'router_uuid'
SUBNET_ID = 'subnet_uuid'
PORT_ID = 'port_uuid'
DEVICE_ID = 'device_uuid'
TEST_TENANT_NAME = 'tenant_name'


class DataMatcher(object):

    def __init__(self, operation, object_type, object_dict):
        self._data = object_dict.copy()
        utils.update_tenant_info(self._data)
        modify_cls = utils_vts.MODIFY_MAP[object_type]
        attr_modify = getattr(modify_cls, 'modify_%s_attributes' % operation)
        self._data, _ = client_vts.filter_excludes(attr_modify(self._data))

    def __eq__(self, s):
        data = jsonutils.loads(s)
        return self._data == data

    def __repr__(self):
        return str(self._data)


class CiscoControllerVTSL3TestCase(
        test_db_base_plugin_v2.NeutronDbPluginV2TestCase):

    def _request_mock(self, *args, **kwargs):
        return self.request_response

    def setUp(self):
        mock.patch.object(sgdriver, 'register').start()
        config.cfg.CONF.set_override("core_plugin",
                                     'neutron.plugins.ml2.plugin.Ml2Plugin')
        core_plugin = config.cfg.CONF.core_plugin
        super(CiscoControllerVTSL3TestCase, self).setUp(plugin=core_plugin)
        config.cfg.CONF.set_override('mechanism_drivers',
                                     ['logger', 'cisco_vts'], 'ml2')
        config.cfg.CONF.set_override('url', 'http://127.0.0.1:9999', 'ml2_cc')
        config.cfg.CONF.set_override('username', 'someuser', 'ml2_cc')
        config.cfg.CONF.set_override('password', 'somepass', 'ml2_cc')
        config.cfg.CONF.set_override('vmm_id', '10', 'ml2_cc')
        mock.patch.object(utils,
                          '_get_tenant_name',
                          return_value=TEST_TENANT_NAME).start()
        self.db_engine = \
            neutron_db_api.context_manager.get_legacy_facade().get_engine()
        self.db_session = neutron_db_api.get_writer_session()
        mock.patch.object(Journal, '_prepare_maintenance_thread').start()
        self.mech = mech_vts.CiscoControllerVTSMechanismDriver()
        self.mech.initialize()

        self.driver = l3_vts.CiscoControllerVTSL3RouterPlugin()
        self.request_response = self._get_mock_request_response(200)
        self.request_mock = mock.patch('requests.request',
                                       side_effect=self._request_mock).start()
        self.thread = self.mech.journal._journal_thread
        self.driver.get_floatingip = mock.Mock(
            return_value={'router_id': ROUTER_ID,
                          'floating_network_id': NETWORK_ID})
        self.addCleanup(self._db_cleanup)
        directory.add_plugin(plugin_constants.L3, self.driver)

    def tearDown(self):
        super(CiscoControllerVTSL3TestCase, self).tearDown()
        Journal._journal_thread = None

    @staticmethod
    def _get_mock_router_operation_info(network, subnet):
        router_context = context.get_admin_context()
        router = {cc_const.CC_ROUTER:
                  {'name': 'router1',
                   'admin_state_up': True,
                   'tenant_id': network['network']['tenant_id'],
                   'tenant_name': TEST_TENANT_NAME,
                   'external_gateway_info': {'network_id':
                                             network['network']['id']}}}
        return router_context, router

    @staticmethod
    def _get_mock_floatingip_operation_info(network, subnet):
        floatingip_context = context.get_admin_context()
        floatingip = {cc_const.CC_FLOATINGIP:
                      {'floating_network_id': network['network']['id'],
                       'tenant_id': network['network']['tenant_id'],
                       'tenant_name': TEST_TENANT_NAME}}
        return floatingip_context, floatingip

    @staticmethod
    def _get_mock_router_interface_operation_info(network, subnet):
        router_intf_context = context.get_admin_context()
        router_intf_dict = {'subnet_id': subnet['subnet']['id'],
                            'id': network['network']['id']}
        return router_intf_context, router_intf_dict

    @classmethod
    def _get_mock_operation_info(cls, object_type, *args):
        getter = getattr(cls, '_get_mock_' + object_type + '_operation_info')
        return getter(*args)

    def _db_cleanup(self):
        rows = db.get_all_db_rows(self.db_session)
        for row in rows:
            db.delete_row(self.db_session, exact_id=row.id)

    @classmethod
    def _get_mock_request_response(cls, status_code):
        response = mock.Mock(status_code=status_code)
        response.raise_for_status = mock.Mock() if status_code < 400 else (
            mock.Mock(side_effect=requests.exceptions.HTTPError(
                cls._status_code_msgs[status_code])))
        return response

    def _test_operation(self, status_code, expected_calls, *args, **kwargs):
        if expected_calls:
            self.request_mock.assert_called_with(
                headers={'Content-Type': 'application/vnd.yang.data+json'},
                auth=(config.cfg.CONF.ml2_cc.username,
                      config.cfg.CONF.ml2_cc.password),
                timeout=config.cfg.CONF.ml2_cc.timeout, *args, **kwargs)
        self.assertEqual(expected_calls, self.request_mock.call_count)
        self.request_mock.reset_mock()

    def _call_operation_object(self, operation, object_type, object_id,
                               network, subnet):
        object_context, object_dict = self._get_mock_operation_info(
            object_type, network, subnet)
        method = getattr(self.driver, operation + '_' + object_type)

        if operation == cc_const.CC_CREATE:
            new_object_dict = method(object_context, object_dict)
        elif operation == cc_const.CC_UPDATE:
            new_object_dict = method(object_context, object_id, object_dict)
        elif operation in [cc_const.CC_ADD, cc_const.CC_REMOVE]:
            router_dict = method(object_context, object_id, object_dict)
            new_object_dict = self.driver._generate_router_dict(
                object_id, object_dict, router_dict)
        else:
            new_object_dict = method(object_context, object_id)

        return object_context, new_object_dict

    def _test_operation_thread_processing(self, object_type, operation,
                                          network, subnet, object_id,
                                          expected_calls=1):
        http_requests = {cc_const.CC_CREATE: 'put',
                         cc_const.CC_UPDATE: 'put',
                         cc_const.CC_DELETE: 'delete',
                         cc_const.CC_ADD: 'put',
                         cc_const.CC_REMOVE: 'delete'}
        status_codes = {cc_const.CC_CREATE: requests.codes.created,
                        cc_const.CC_UPDATE: requests.codes.ok,
                        cc_const.CC_DELETE: requests.codes.no_content,
                        cc_const.CC_ADD: requests.codes.created,
                        cc_const.CC_REMOVE: requests.codes.created}

        http_request = http_requests[operation]
        status_code = status_codes[operation]
        self.request_response = self._get_mock_request_response(status_code)

        # Create database entry.
        object_context, new_object_dict = self._call_operation_object(
            operation, object_type, object_id, network, subnet)

        # Setup expected results.
        if operation is cc_const.CC_CREATE:
            url = (config.cfg.CONF.ml2_cc.url + '/vmm/10/' +
                   object_type + '/' + new_object_dict['id'])
        elif operation is cc_const.CC_UPDATE:
            if object_type is cc_const.CC_ROUTER:
                url = (config.cfg.CONF.ml2_cc.url + '/vmm/10/' + object_type
                       + '/' + object_id + '/' + utils_vts.ROUTER_GATEWAY +
                       '/')
            else:
                url = (config.cfg.CONF.ml2_cc.url + object_type + '/' +
                       object_id)
        elif operation is cc_const.CC_DELETE:
            url = (config.cfg.CONF.ml2_cc.url + '/vmm/10/' + object_type +
                   '/' +
                   object_id)
        elif operation in [cc_const.CC_ADD, cc_const.CC_REMOVE]:
            url = (config.cfg.CONF.ml2_cc.url + '/vmm/10' + '/interfaces/' +
                   subnet['subnet']['id'])

        if operation in [cc_const.CC_CREATE, cc_const.CC_UPDATE,
                         cc_const.CC_ADD]:
            kwargs = {'data': DataMatcher(operation, object_type,
                                          new_object_dict)}
        else:
            kwargs = {'data': None}

        kwargs.update({'url': url, 'verify': False})

        # Call threading routine to process database entry. Test results.
        self._wait_processing()
        self._test_operation(status_code, expected_calls, http_request,
                             **kwargs)

        return new_object_dict

    def _test_thread_processing(self, object_type):
        # Create network and subnet.
        kwargs = {'arg_list': (external_net.EXTERNAL,),
                  external_net.EXTERNAL: True}
        with self.network(**kwargs) as network:
            with self.subnet(network=network, cidr='10.0.0.0/24') as subnet:
                # Add and process create request.
                new_object_dict = self._test_operation_thread_processing(
                    object_type, cc_const.CC_CREATE, network, subnet, None)
                object_id = new_object_dict['id']
                rows = db.get_ordered_rows(self.db_session)
                self.assertEqual(0, rows.count())

                # Add and process 'update' request. Adds to database.
                self._test_operation_thread_processing(
                    object_type, cc_const.CC_UPDATE, network, subnet,
                    object_id)
                rows = db.get_ordered_rows(self.db_session)
                self.assertEqual(0, rows.count())

                # Add and process 'delete' request. Adds to database.
                self._test_operation_thread_processing(
                    object_type, cc_const.CC_DELETE, network, subnet,
                    object_id)
                rows = db.get_ordered_rows(self.db_session)
                self.assertEqual(0, rows.count())

    def _wait_processing(self):
        self.thread.wait_processing()

    def _test_db_results(self, object_id, operation, object_type):
        op_to_rest_cmd = {'create': 'put',
                          'add': 'put',
                          'update': 'put',
                          'delete': 'delete',
                          'remove': 'delete'}
        create_type_to_key = {'router_interface': 'interfaces'}
        id_translation = {'interfaces': 'router-id'}
        update_type_to_key = {'router': 'router-gateway'}

        self._wait_processing()
        self.assertEqual(1, self.request_mock.call_count)
        args, kwargs = self.request_mock.call_args
        self.request_mock.reset_mock()

        self.assertEqual(op_to_rest_cmd[operation], args[0])
        if operation == 'delete' or operation == 'remove':
            return
        data = jsonutils.loads(kwargs['data'])
        if operation == 'create' or operation == 'add':
            t = (object_type if object_type not in create_type_to_key
                 else create_type_to_key[object_type])
            i = ('id' if t not in id_translation else id_translation[t])
            self.assertEqual(t, next(iter(data.keys())))
            self.assertEqual(object_id, data[t][i])
        else:
            self.assertEqual(update_type_to_key[object_type],
                             next(iter(data.keys())))

    def _test_object_db(self, object_type):
        # Create network and subnet for testing.
        kwargs = {'arg_list': (external_net.EXTERNAL,),
                  external_net.EXTERNAL: True}
        with self.network(**kwargs) as network:
            with self.subnet(network=network):
                object_context, object_dict = self._get_mock_operation_info(
                    object_type, network, None)

                # Add and test 'create' database entry.
                method = getattr(self.driver,
                                 cc_const.CC_CREATE + '_' + object_type)
                new_object_dict = method(object_context, object_dict)
                object_id = new_object_dict['id']
                self._test_db_results(object_id, cc_const.CC_CREATE,
                                      object_type)

                # Add and test 'update' database entry.
                method = getattr(self.driver,
                                 cc_const.CC_UPDATE + '_' + object_type)
                method(object_context, object_id, object_dict)
                self._test_db_results(object_id, cc_const.CC_UPDATE,
                                      object_type)

                # Add and test 'delete' database entry.
                method = getattr(self.driver,
                                 cc_const.CC_DELETE + '_' + object_type)
                method(object_context, object_id)
                self._test_db_results(object_id, cc_const.CC_DELETE,
                                      object_type)

    def test_router_db(self):
        self._test_object_db(cc_const.CC_ROUTER)

    def _test_floatingip_db(self):
        self._test_object_db(cc_const.CC_FLOATINGIP)

    def test_router_intf_db(self):
        # Create network, subnet and router for testing.
        kwargs = {'arg_list': (external_net.EXTERNAL,),
                  external_net.EXTERNAL: True}
        with self.network(**kwargs) as network:
            with self.subnet(cidr='10.0.0.0/24') as subnet:
                router_context, router_dict = (
                    self._get_mock_router_operation_info(network, None))
                new_router_dict = self.driver.create_router(router_context,
                                                            router_dict)
                router_id = new_router_dict['id']

                object_type = cc_const.CC_ROUTER_INTF
                router_intf_context, router_intf_dict = \
                    self._get_mock_router_interface_operation_info(network,
                                                                   subnet)

                # Process 'router' database entry to allow tests to pass.
                self._wait_processing()
                self.request_mock.reset_mock()

                # Add and test router interface 'add' database entry.
                # Note that router interface events do not generate unique
                # UUIDs.
                self.driver.add_router_interface(router_intf_context,
                                                 router_id, router_intf_dict)
                self._test_db_results(router_id,
                                      cc_const.CC_ADD, object_type)

                # Add and test 'remove' database entry.
                self.driver.remove_router_interface(router_intf_context,
                                                    router_id,
                                                    router_intf_dict)
                self._test_db_results(cc_const.CC_UUID_NOT_USED,
                                      cc_const.CC_REMOVE, object_type)

    def test_router_threading(self):
        self._test_thread_processing(cc_const.CC_ROUTER)

    def _test_floatingip_threading(self):
        self._test_thread_processing(cc_const.CC_FLOATINGIP)

    def test_router_intf_threading(self):
        # Create network, subnet and router for testing.
        kwargs = {'arg_list': (external_net.EXTERNAL,),
                  external_net.EXTERNAL: True}
        with self.network(**kwargs) as network:
            with self.subnet(cidr='10.0.0.0/24') as subnet:
                router_context, router_dict = (
                    self._get_mock_router_operation_info(network, None))
                new_router_dict = self.driver.create_router(router_context,
                                                            router_dict)
                router_id = new_router_dict['id']
                object_type = cc_const.CC_ROUTER_INTF

                # Add and process router interface 'add' request. Adds to
                # database. Expected calls = 2 because the create_router db
                # entry is also processed.
                self._test_operation_thread_processing(
                    object_type, cc_const.CC_ADD, network, subnet, router_id,
                    expected_calls=2)
                rows = db.get_ordered_rows(self.db_session)
                self.assertEqual(0, rows.count())

                # Add and process 'remove' request. Adds to database.
                self._test_operation_thread_processing(
                    object_type, cc_const.CC_REMOVE, network, subnet,
                    router_id)
                rows = db.get_ordered_rows(self.db_session)
                self.assertEqual(0, rows.count())
