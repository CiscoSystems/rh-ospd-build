# Copyright (c) 2015 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import abc
import six

from cisco_controller.common import constants as cc_const
from cisco_controller.common import utils as cc_utils


HTTP_METHOD_MAP = {
    cc_const.CC_CREATE: 'post',
    cc_const.CC_UPDATE: 'put',
    cc_const.CC_DELETE: 'delete',
    cc_const.CC_ADD: 'put',
    cc_const.CC_REMOVE: 'put',
}


def CreateURLpath(url_object, row):
    return url_object + 's'


def UpdateURLpath(url_object, row):
    return url_object + 's/' + row.object_uuid


def DeleteURLpath(url_object, row):
    return url_object + 's/' + row.object_uuid


def AddRouterInterfaceURLpath(url_object, row):
    return 'routers/' + row.data['id'] + '/add_router_interface'


def RemoveRouterInterfaceURLpath(url_object, row):
    return 'routers/' + row.data['id'] + '/remove_router_interface'


URL_PATH_MAP = {
    cc_const.CC_CREATE: CreateURLpath,
    cc_const.CC_UPDATE: UpdateURLpath,
    cc_const.CC_DELETE: DeleteURLpath,
    cc_const.CC_ADD: AddRouterInterfaceURLpath,
    cc_const.CC_REMOVE: RemoveRouterInterfaceURLpath,
}


@six.add_metaclass(abc.ABCMeta)
class ResourceModifyBase(object):
    @staticmethod
    @abc.abstractmethod
    def modify_create_attributes(resource):
        pass

    @staticmethod
    @abc.abstractmethod
    def modify_update_attributes(resource):
        pass


class NetworkModify(ResourceModifyBase):
    @staticmethod
    def modify_create_attributes(network):
        """Modify out network attributes not required for a create."""
        cc_utils.try_del(network, ['status', 'subnets'])
        return {cc_const.CC_NETWORK: network}

    @staticmethod
    def modify_update_attributes(network):
        """Modify out network attributes for an update operation."""
        cc_utils.try_del(network, ['id', 'status', 'subnets', 'tenant_id'])
        return {cc_const.CC_NETWORK: network}


class SubnetModify(ResourceModifyBase):
    @staticmethod
    def modify_create_attributes(subnet):
        """Modify out subnet attributes not required for a create."""
        return {cc_const.CC_SUBNET: subnet}

    @staticmethod
    def modify_update_attributes(subnet):
        """Modify out subnet attributes for an update operation."""
        cc_utils.try_del(subnet, ['id', 'network_id', 'ip_version', 'cidr',
                         'allocation_pools', 'tenant_id'])
        return {cc_const.CC_SUBNET: subnet}


class PortModify(ResourceModifyBase):
    @classmethod
    def modify_create_attributes(cls, port):
        """Modify out port attributes not required for a create."""
        # TODO(kmestery): Converting to uppercase due to CC bug
        # https://bugs.opendaylight.org/show_bug.cgi?id=477
        port['mac_address'] = port['mac_address'].upper()
        cc_utils.try_del(port, ['status'])
        return {cc_const.CC_PORT: port}

    @classmethod
    def modify_update_attributes(cls, port):
        """Modify out port attributes for an update operation."""
        cc_utils.try_del(port, ['network_id', 'id', 'status', 'mac_address',
                         'tenant_id', 'fixed_ips'])
        return {cc_const.CC_PORT: port}


class SecurityGroupModify(ResourceModifyBase):
    @staticmethod
    def modify_create_attributes(sg, context):
        """Modify out security-group attributes not required for a create."""
        return context

    @staticmethod
    def modify_update_attributes(sg, context):
        """Modify out security-group attributes for an update operation."""
        return context


class SecurityGroupRuleModify(ResourceModifyBase):
    @staticmethod
    def modify_create_attributes(sg_rule, context):
        """Modify out sg-rule attributes not required for a create."""
        return context

    @staticmethod
    def modify_update_attributes(sg_rule, context):
        """Modify out sg-rule attributes for an update operation."""
        return context


class RouterModify(ResourceModifyBase):
    @staticmethod
    def modify_create_attributes(router):
        """Modify out attributes not required for a create."""
        return {cc_const.CC_ROUTER: router}

    @staticmethod
    def modify_update_attributes(router):
        """Modify out attributes for an update operation."""
        cc_utils.try_del(router, ['id', 'tenant_id', 'status'])
        return {cc_const.CC_ROUTER: router}


class FloatingIPModify(ResourceModifyBase):
    @staticmethod
    def modify_create_attributes(floatingip):
        """Modify out attributes not required for a create."""
        return {cc_const.CC_FLOATINGIP: floatingip}

    @staticmethod
    def modify_update_attributes(floatingip):
        """Modify out attributes for an update operation."""
        return {cc_const.CC_FLOATINGIP: floatingip}


class RouterIntfModify(ResourceModifyBase):
    @staticmethod
    def modify_add_attributes(routerintf):
        """Modify out attributes not required for a create."""
        return {cc_const.CC_ROUTER_INTF: routerintf}

    @staticmethod
    def modify_remove_attributes(routerintf):
        """Modify out attributes for an update operation."""
        return {cc_const.CC_ROUTER_INTF: routerintf}


MODIFY_MAP = {
    cc_const.CC_NETWORK: NetworkModify,
    cc_const.CC_SUBNET: SubnetModify,
    cc_const.CC_PORT: PortModify,
    cc_const.CC_ROUTER: RouterModify,
    cc_const.CC_ROUTER_INTF: RouterIntfModify,
    cc_const.CC_FLOATINGIP: FloatingIPModify,
}
