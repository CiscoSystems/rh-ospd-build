# Copyright (c) 2015 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
import abc
import re
import six

from oslo_log import log

from cisco_controller.common import constants as cc_const
from cisco_controller.common import utils as cc_utils

from neutron.common import constants as n_consts
from neutron_lib.api.definitions import portbindings

LOG = log.getLogger(__name__)

VTS_IDS_MODULE = 'cisco-vts-identities:'
VTS_OS_IDS_MODULE = 'cisco-vts-openstack-identities:'
IPV6_RA_MODE = 'ipv6-ra-mode'
IPV6_ADDRESS_MODE = 'ipv6-address-mode'
ROUTER_GATEWAY = 'router-gateway'
INTERFACES = 'interfaces'

SECURITY_GROUP = 'security-group'
SECURITY_GROUP_RULE = 'security-group-rule'
SECURITY_GROUP_RULES = 'security-group-rules'

sgrule_ignore_keys = ["created_at", "updated_at", "project_id",
                      "revision_number", "tenant_id",
                      "description", "tenant_name"]
group_ignore_keys = ["created_at", "updated_at", "project_id",
                     "revision_number"]


HTTP_METHOD_MAP = {
    cc_const.CC_CREATE: 'put',
    cc_const.CC_UPDATE: 'put',
    cc_const.CC_DELETE: 'delete',
    cc_const.CC_ADD: 'put',
    cc_const.CC_REMOVE: 'delete',
}


def CreateDeleteURLpath(url_object, row):
    if url_object == SECURITY_GROUP_RULE:
        urlpath = SECURITY_GROUP + '/' + row.data['security_group_id'] \
            + "/" + SECURITY_GROUP_RULES + "/" + row.object_uuid
    else:
        urlpath = url_object + '/' + row.object_uuid
    return urlpath


def UpdateURLpath(url_object, row):
    if url_object == cc_const.CC_ROUTER:
        urlpath = url_object + '/' + row.object_uuid + '/' + \
            ROUTER_GATEWAY + '/'
    else:
        urlpath = url_object + '/' + row.object_uuid
    return urlpath


def AddRemoveURLpath(url_object, row):
    return INTERFACES + '/' + row.data['subnet_id']


URL_PATH_MAP = {
    cc_const.CC_CREATE: CreateDeleteURLpath,
    cc_const.CC_UPDATE: UpdateURLpath,
    cc_const.CC_DELETE: CreateDeleteURLpath,
    cc_const.CC_ADD: AddRemoveURLpath,
    cc_const.CC_REMOVE: AddRemoveURLpath,
}


class ResourceModifyMeta(abc.ABCMeta):
    def __init__(cls, name, bases, dct):
        super(ResourceModifyMeta, cls).__init__(name, bases, dct)
        prefix = cls._hidden_prefix()
        if prefix is None:
            cls._hidden_tenant = None
            return
        cls._hidden_tenant = re.compile('^' +
                                        (prefix % '([0-9a-fA-F]+)') +
                                        '$')


@six.add_metaclass(ResourceModifyMeta)
class ResourceModifyBase(object):
    @staticmethod
    @abc.abstractmethod
    def _hidden_prefix():
        return None

    @classmethod
    def translate_invisible_tenant_id(cls, resource):
        if cls._hidden_tenant is None or 'name' not in resource:
            return
        match = cls._hidden_tenant.match(resource['name'])
        if match is None:
            return
        resource['tenant_id'] = match.groups()[0]

    @classmethod
    def modify_create_attributes(cls, resource):
        cls.translate_invisible_tenant_id(resource)
        cc_utils.update_tenant_info(resource)
        return cls._modify_create_attributes(resource)

    @classmethod
    def modify_update_attributes(cls, resource):
        cls.translate_invisible_tenant_id(resource)
        cc_utils.update_tenant_info(resource)
        return cls._modify_update_attributes(resource)

    @classmethod
    def modify_add_attributes(cls, resource):
        cc_utils.update_tenant_info(resource)
        return cls._modify_add_attributes(resource)

    @staticmethod
    @abc.abstractmethod
    def _modify_create_attributes(resource):
        pass

    @staticmethod
    @abc.abstractmethod
    def _modify_update_attributes(resource):
        pass


class NetworkModify(ResourceModifyBase):
    @staticmethod
    def _hidden_prefix():
        return n_consts.HA_NETWORK_NAME

    @staticmethod
    def _modify_create_attributes(network):
        """Modify out network attributes not required for a create."""
        # Need to append module names to identityref values
        network['provider:network_type'] = (VTS_IDS_MODULE +
                                            network['provider:network_type'])
        network['status'] = VTS_OS_IDS_MODULE + network['status']
        network = _escape_keys(network)
        return {cc_const.CC_NETWORK: network}

    @staticmethod
    def _modify_update_attributes(network):
        """Modify out network attributes for an update operation."""
        # Need to append module names to identityref values
        LOG.debug('Network data %s', str(network))
        # Need to append module names to identityref values
        if(network['provider:network_type'] is not None):
            network['provider:network_type'] = \
                (VTS_IDS_MODULE + network['provider:network_type'])
            network['status'] = VTS_OS_IDS_MODULE + network['status']
            network = _escape_keys(network)
        else:
            network['status'] = VTS_OS_IDS_MODULE + network['status']
            network = _escape_keys(network)

        return {cc_const.CC_NETWORK: network}


class SubnetModify(ResourceModifyBase):
    @staticmethod
    def _hidden_prefix():
        return n_consts.HA_SUBNET_NAME

    @staticmethod
    def _modify_create_attributes(subnet):
        if IPV6_RA_MODE in subnet:
            subnet[IPV6_RA_MODE] = VTS_IDS_MODULE + subnet[IPV6_RA_MODE]
        if IPV6_ADDRESS_MODE in subnet:
            subnet[IPV6_ADDRESS_MODE] = (VTS_IDS_MODULE +
                                         subnet[IPV6_ADDRESS_MODE])
        subnet = _escape_keys(subnet)
        return {cc_const.CC_SUBNET: subnet}

    @staticmethod
    def _modify_update_attributes(subnet):
        if IPV6_RA_MODE in subnet:
            subnet[IPV6_RA_MODE] = VTS_IDS_MODULE + subnet[IPV6_RA_MODE]
        if IPV6_ADDRESS_MODE in subnet:
            subnet[IPV6_ADDRESS_MODE] = (VTS_IDS_MODULE +
                                         subnet[IPV6_ADDRESS_MODE])
        subnet = _escape_keys(subnet)
        return {cc_const.CC_SUBNET: subnet}


class PortModify(ResourceModifyBase):

    @staticmethod
    def _hidden_prefix():
        return n_consts.HA_PORT_NAME

    @classmethod
    def modify_attributes(cls, port):
        # Need to append module names to identityref values
        port['status'] = VTS_OS_IDS_MODULE + port['status']

        security_groups = port.get('security_groups', None)
        if security_groups:
            port['security_groups'] = [{'id': sg} for sg in security_groups]

        if port['binding:vif_type'] == 'vhostuser':
            port['binding:vif_details'][portbindings.VHOST_USER_MODE] = \
                VTS_OS_IDS_MODULE + portbindings.VHOST_USER_MODE_SERVER
        port['binding:vif_type'] = (VTS_OS_IDS_MODULE +
                                    port['binding:vif_type'])
        filter = port.get('binding:vif_details', {}).get('port_filter', False)
        port['binding:vif_details']['port_filter'] = filter

        # modify segmentation type in trunk details to be cisco-vts-ids
        if 'trunk_details' in port:
            for s in port['trunk_details']['sub_ports']:
                s['segmentation_type'] = VTS_IDS_MODULE + \
                    s['segmentation_type']

        port = _escape_keys(port)
        return {cc_const.CC_PORT: port}

    @classmethod
    def _modify_create_attributes(cls, port):
        """Modify out port attributes not required for a create."""
        return cls.modify_attributes(port)

    @classmethod
    def _modify_update_attributes(cls, port):
        """Modify out port attributes for an update operation."""
        return cls.modify_attributes(port)


def set_value_rule(rule, key, value, default_value=None):
    rule[key] = value if rule.get(key, None) else default_value


def get_default_ip_prefix(rule):
    # OpenStack provides 'None' for Egress and Ingress rules when SG gets
    # created, when infact it represents 'Any', if the remote group
    # reference is not present. Hence, the default is
    # inferred as below.
    if not rule.get('remote_group_id'):
        default_ip_prefix = '0.0.0.0/0' if rule.get('ethertype',
                                                    None) == 'IPv4' else '::/0'
    else:
        default_ip_prefix = None
    return default_ip_prefix


def modify_values_rule(rule):
    set_value_rule(rule, 'remote_ip_prefix', rule['remote_ip_prefix'],
                   get_default_ip_prefix(rule))
    set_value_rule(rule, 'direction', VTS_IDS_MODULE + rule['direction'], None)
    set_value_rule(rule, 'ethertype', VTS_IDS_MODULE +
                   rule['ethertype'].lower(), None)
    set_value_rule(rule, 'port_range_max', rule['port_range_max'], 0)
    set_value_rule(rule, 'port_range_min', rule['port_range_min'], 0)
    set_value_rule(rule, 'protocol', rule['protocol'], 'ip')
    set_value_rule(rule, 'remote_group_id', rule['remote_group_id'], None)

    LOG.info("Rule after modifying values: %(rule)s",
             {'rule': str(rule)})


def get_null_keys_rule(rule):
    rule_ignore_keys = [key for key, value in six.iteritems(rule) if
                        value is None] + sgrule_ignore_keys
    LOG.debug("Ignoring following keys: %(keys)s",
              {'keys': str(rule_ignore_keys)})
    return rule_ignore_keys


class SecurityGroupModify(ResourceModifyBase):
    @classmethod
    def modify_attributes(cls, sg):
        rules = sg.get('security_group_rules', [])
        for rule in rules:
            modify_values_rule(rule)
            rule_ignore_keys = get_null_keys_rule(rule)
            cc_utils.try_del(rule, rule_ignore_keys)

        cc_utils.try_del(sg, group_ignore_keys)
        sg = _escape_keys(sg)
        LOG.debug("Payload after escaping and removing Null keys: %("
                  "data)s", {"data": str(sg)})
        return {SECURITY_GROUP: sg}

    @classmethod
    def _modify_create_attributes(cls, sg):
        """Modify out security-group attributes for a create operation"""
        return cls.modify_attributes(sg)

    @classmethod
    def _modify_update_attributes(cls, sg):
        """Modify out security-group attributes for an update operation."""
        return cls.modify_attributes(sg)


class SecurityGroupRuleModify(ResourceModifyBase):
    @classmethod
    def modify_attributes(cls, sg_rule):
        modify_values_rule(sg_rule)
        rule_ignore_keys = get_null_keys_rule(sg_rule)
        cc_utils.try_del(sg_rule, rule_ignore_keys)
        sg_rule = _escape_keys(sg_rule)
        return {SECURITY_GROUP_RULES: sg_rule}

    @classmethod
    def _modify_create_attributes(cls, sg_rule):
        """Modify out sg-rule attributes required for create operation."""
        return cls.modify_attributes(sg_rule)


class RouterModify(ResourceModifyBase):
    @staticmethod
    def _modify_create_attributes(router):
        """Modify out attributes not required for a create."""
        router['status'] = VTS_OS_IDS_MODULE + router['status']
        external_gateway_info = router.get('external_gateway_info', None)
        network_id = (external_gateway_info['network_id']
                      if external_gateway_info is not None else None)
        router[ROUTER_GATEWAY] = network_id
        cc_utils.try_del(router, ['external_gateway_info', 'distributed',
                                  'admin_state_up', 'gw_port_id'])
        router = _escape_keys(router)
        return {cc_const.CC_ROUTER: router}

    @staticmethod
    def _modify_update_attributes(router):
        """Modify out attributes for an update operation."""
        # TODO(rcurran): Original driver sent delete (using update URL)
        #                if external_gateway_info is None.
        external_gateway_info = router.get('external_gateway_info', None)
        network_id = (external_gateway_info['network_id']
                      if external_gateway_info is not None else None)
        # Adding the ROUTER_GATEWAY: "" to handle clear gateway scenario
        # as VTC reject netowrk_id: null refer-CSCve37680
        return {ROUTER_GATEWAY: ""} if network_id is None \
            else {ROUTER_GATEWAY: network_id}


class FloatingIPModify(ResourceModifyBase):
    @staticmethod
    def _modify_create_attributes(floatingip):
        """Modify out attributes not required for a create."""
        pass

    @staticmethod
    def _modify_update_attributes(floatingip):
        """Modify out attributes for an update operation."""

        pass


class TrunkModify(ResourceModifyBase):
    @classmethod
    def modify_attributes(cls, trunk):
        # Need to append module names to identityref values
        subports = []
        t = trunk['current_trunk'] or trunk['original_trunk']

        for s in t['sub_ports']:
            subports.append({'port-id': s['port_id'],
                             'segmentation-id': s['segmentation_id'],
                             'segmentation-type': VTS_IDS_MODULE +
                             s['segmentation_type']})
        payload = {'id': trunk['trunk_id'],
                   'name': t['name'],
                   'port-id': t['port_id'],
                   'tenant-name': trunk['tenant_name'],
                   'sub-ports': subports}

        payload = _escape_keys(payload)
        return {cc_const.CC_TRUNK: payload}

    @classmethod
    def _modify_create_attributes(cls, trunk):
        """Modify out trunk attributes not required for a create."""
        return cls.modify_attributes(trunk)

    @classmethod
    def _modify_update_attributes(cls, trunk):
        """Modify out trunk attributes for an update operation."""
        return cls.modify_attributes(trunk)


class RouterIntfModify(ResourceModifyBase):
    @staticmethod
    def _modify_add_attributes(routerintf):
        """Modify out attributes not required for a create."""
        routerintf['ip-address'] = cc_utils.get_portipaddress_from_portid(
            routerintf['port_id'], routerintf['subnet_id'])
        routerintf['router-id'] = routerintf['id']
        cc_utils.try_del(routerintf, ['id', 'tenant_id', 'port_id'])
        routerintf = _escape_keys(routerintf)
        return {INTERFACES: routerintf}

    @staticmethod
    def modify_remove_attributes(routerintf):
        """Modify out attributes for an update operation."""
        pass


MODIFY_MAP = {
    cc_const.CC_NETWORK: NetworkModify,
    cc_const.CC_SUBNET: SubnetModify,
    cc_const.CC_PORT: PortModify,
    cc_const.CC_ROUTER: RouterModify,
    cc_const.CC_ROUTER_INTF: RouterIntfModify,
    cc_const.CC_FLOATINGIP: FloatingIPModify,
    cc_const.CC_TRUNK: TrunkModify,
    cc_const.CC_SG: SecurityGroupModify,
    cc_const.CC_SG_RULE: SecurityGroupRuleModify
}


def _escape_keys(obj):
    """Escape JSON keys to be NCS compatible.

    NCS does not allow period (.) or colon (:) characters.
    """
    escape = lambda string: re.sub('[:._]', '-', string)
    if isinstance(obj, dict):
        obj = dict((escape(k), _escape_keys(v))
                   for k, v in six.iteritems(obj))
    if isinstance(obj, list):
        obj = [_escape_keys(x) for x in obj]
    return obj
